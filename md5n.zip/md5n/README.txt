md5n - Fabric client mod (Minecraft Java 1.21.4)

البناء: ارفع md5n.zip لمستودع GitHub (مع ملف .github/workflows/build.yml) وحمّل md5n-jar من تبويب Actions.
أو على ويندوز: فك الزيب وشغّل build.bat (قد يحجبه Smart App Control).

فتح القائمة: Right Shift + Space (تغيّره من Theme ← Menu Key)

القائمة:
- لوحات بالفئات (Combat / Movement / Visual / Client)، اسحب الهيدر تحرّكها، وكليك عليه يطويها
- كليك يسار على المود: تشغيل/إطفاء (مع صوت)
- كليك يمين: فتح/إغلاق إعدادات المود
- كليك وسط على المود: ربط مفتاح بتشغيله
- كليك وسط على أي خيار ON/OFF أو Mode: ربط مفتاح يبدّله
- اكتب مباشرة في الشاشة للبحث عن مود
- الإعدادات والمفاتيح تنحفظ تلقائياً في config/md5n.json

ElytraTarget: اضغط مفتاح القفل (الافتراضي G) وأنت تطير ليقفل على أقرب هدف لاتجاه نظرك،
وبعدها يلحقه ويطلق الصواريخ تلقائياً. اضغط G مرة ثانية لإلغاء القفل.

لإضافة مود: انسخ Sprint.java كقالب، واستخدم bool(...) و num(...) و mode(...) و keybind(...)، وسجّله في ModuleManager.

ستايل Glass (الافتراضي): لوحات زجاجية بزوايا مدورة وتوهج، وHUD بحبوب (إحداثيات / اسم + FPS + سيرفر + ساعة / سرعة مع رسم بياني).
تبدّل بينه وبين Classic من Theme ← Style، والألوان من Theme ← Theme (Emerald هو الأخضر الجديد).

PlayerAlert (Visual): ينبّهك بصوت ورسالة فوق الهوت بار لما يقرب منك لاعب (المسافة من الإعدادات)، مع اسمه ومسافته واتجاهه (N/E/S/W).

VFX ← Sky: يغيّر لون السماء (الأوفرورلد). 10 ستايلات: 5 ثابتة (Sunset, Twilight, Blood, Emerald, Void)
و5 متحركة (Rainbow, Aurora, Pulse, Lava, Dream). الخيارات: Speed و Brightness و Day/Night Blend.
(هذا المود يستخدم Mixin: ملف md5n.mixins.json)

Cosmetic ← Kill VFX: تأثيرات جسيمات لما تقتل لاعب (10 أنواع + Random): Burst, Soul Rise, Lightning, Totem, Ring Wave,
Meteor, Portal, Hearts, Cherry, Galaxy. مفتاح Test Key (الافتراضي J) يعرض التأثير قدامك للتجربة.
VFX ← Ambiance: 12 تأثير جوّي تشغّلهم/تطفيهم من الإعدادات: Fireflies, Sparkles, Snowfall, Cherry Petals, Embers,
Ash Fall, Spores, Soul Wisps, Magic Glyphs, Mist, Dragon Breath, Void Dust.
(الجسيمات تظهر فقط لو إعداد Particles في ماينكرافت مو Minimal)

Cosmetic (7 مودات، كل واحد 10 ستايلات): Hat, Aura, Trail, Back, Jump VFX, Cape, Wing.
- كلها مبنية من جسيمات حولك وتظهر لك أنت بس. اضغط F5 (منظور ثالث) عشان تشوفها.
- الألوان مربوطة بـ Theme: لون الواجهة (وRainbow Accent) هو لون الكوزمتك. تطفي Theme ← Sync Cosmetics لو تبي لون مختلف لكل واحد.
- خيار VFX في كل كوزمتك يضيف تأثيرات فوقه (Sparkle, Glow, Flame, Soul, Magic, Electric, Snow, Petals).

الإصدار 0.9.0:
- VFX كلها صارت مخصصة (محرك Neon): ما فيه أي جسيمة من ماينكرافت. المؤثرات تُحسب وتُرسم فوق الشاشة بتوهج.
  * Kill VFX: Orbit, Spiral, Flare, Constellation, Satellite, Storm, Rift, Shackles, Singularity, Swarm (+ Random) و Palette (الافتراضي Neon Pink).
  * Ambiance: نفس التأثيرات الـ12 لكن بأشكال مخصصة (ندف ثلج، بتلات، رونز، همسات...).
  * الكوزمتك و Jump VFX و خيار VFX فوقها تمر بنفس المحرك.
  * لو المؤثرات تبين مزاحة عن العالم (مثلاً وأنت تركض) عدّل Theme ← VFX FOV Offset. و VFX Glow للسطوع.
- Sky: أُعيد كتابته. الربط صار يشتغل سواء رجعت اللعبة اللون كـ Vec3d أو int، ويلوّن الغيوم، ويطلع لك تنبيه لو الربط ما اشتغل.

الإصدار 0.10.0:
- إصلاح: Fireworks.java كان يستخدم inv.getSelectedSlot()/setSelectedSlot() اللي مو موجودة بهذا الإصدار، رجّعتها inv.selectedSlot (حقل عام).
- زر "Disable All" في الشريط العلوي للقائمة: يطفي كل المودات دفعة وحدة ويحفظ الحالة في config/md5n.json (مع try/catch).
- مود جديد TargetHUD (Combat): بطاقة صغيرة تثبت بجانب الهدف اللي تقاتله (اسمه، صحة بشريط متحرك، المسافة، سلاحه لو لاعب)،
  وصف سفلي فيه الكومبو وعدد الضربات (لاندد-محاولات) وفرق الارتفاع بينك وبينه. الأفاتار حرف أول من الاسم (مو سكن حقيقي)،
  وأيقونة السلاح أيقونة العنصر الحقيقية من اللعبة. إعداداتها: Range, Players/Hostile/Passive, Weapon Tag, Offset X/Y,
  Combo Window, Linger, Health Bar Speed.

0.10.1: نقلت Kill VFX من قائمة VFX إلى قائمة Cosmetic (جنب Hat وAura وTrail...)، بدون أي تغيير في سلوكه أو ستايلاته
(Shackles وOrbit وStorm وSwarm وباقي الأنواع كما هي، ومربوطة بنفس نظام ألوان Theme).

0.11.0: مود Aura صار يقدر يلف حول لاعبين/مخلوقات قريبة باستمرار بدل حولك بس.
فعّل "Target Others" في إعداداته، وحدد Players/Hostile Mobs/Passive Mobs وTarget Range وMax Targets.
نفس العشر ستايلات (Rings, Spiral, Orbit...) تظل تشتغل، بس على كل هدف قريب كل تيك بدل مرة وحدة عند القتل.
ملاحظة: هذا يعرض مواقع لاعبين من خلال الجدران، وغالباً يُعتبر غش ESP من قبل أي سيرفر عام ويعرضك للحظر — استخدمه بس في سنقل بلاير أو سيرفرك الخاص.
