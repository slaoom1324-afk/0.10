package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Fireworks;

public class ElytraAssist extends Module {
    private final NumSetting minSpeed = num("Min Speed (b/s)", 25, 5, 60, 1, "Fire a rocket when slower than this");
    private final NumSetting delay = num("Delay (ticks)", 25, 5, 60, 1, "Ticks between rockets (20 = 1 second)");
    private final BoolSetting requireForward = bool("Require W", true, "Only fire while holding forward");

    private int timer;

    public ElytraAssist() {
        super("ElytraAssist", Category.MOVEMENT, "Auto-fires fireworks while gliding to keep your speed up");
    }

    @Override
    protected void onEnable() {
        timer = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (timer > 0) timer--;
        if (timer > 0 || mc.currentScreen != null) return;

        if (!mc.player.isGliding()) return;
        if (requireForward.get() && !mc.options.forwardKey.isPressed()) return;

        double speed = mc.player.getVelocity().length() * 20.0;
        if (speed >= minSpeed.get()) return;

        if (Fireworks.use()) timer = delay.getInt();
    }
}
