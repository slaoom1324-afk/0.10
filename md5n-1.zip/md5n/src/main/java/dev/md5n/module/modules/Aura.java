package dev.md5n.module.modules;

import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Colors;
import dev.md5n.util.Targets;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Aura extends Cosmetic {
    // لو "Target Others" مطفي: الهالة تلف حولك بس (زي ما كانت دايماً).
    // لو مشغّل: نفس الهالة تلف حول كل كيان صالح قريب منك، باستمرار، مو مرة وحدة.
    private final BoolSetting targetOthers = bool("Target Others", false,
            "Wrap this aura around nearby entities instead of yourself, continuously");
    private final BoolSetting targetPlayers = bool("Players", true, "Include nearby players");
    private final BoolSetting targetHostile = bool("Hostile Mobs", false, "Include nearby hostile mobs");
    private final BoolSetting targetPassive = bool("Passive Mobs", false, "Include nearby animals and villagers");
    private final NumSetting targetRange = num("Target Range", 24, 4, 60, 1, "Max distance to show the aura on others");
    private final NumSetting maxTargets = num("Max Targets", 6, 1, 12, 1, "Caps how many entities get an aura at once (keeps FPS smooth)");

    public Aura() {
        super("Aura", "Particle aura around your body (press F5 to see), or around nearby entities",
                new String[]{"Rings", "Spiral", "Orbit", "Shell", "Pulse", "Flames", "Vortex", "Electric", "Bubbles", "Constellation"});
    }

    private void sphere(double r, double cy, int rgb) {
        double u = rnd() * 2.0 - 1.0;
        double th = rnd() * TAU;
        double s = Math.sqrt(1.0 - u * u);
        put(r * s * Math.cos(th), cy + r * u, r * s * Math.sin(th), rgb);
    }

    // ------------------------------------------------------------ التشغيل

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        if (!targetOthers.get()) {
            // السلوك الأصلي: الهالة حولك بس
            if (!firstPerson.get() && mc.options.getPerspective().isFirstPerson()) return;
            prepare();
            emit(style.get());
            return;
        }

        List<LivingEntity> targets = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (!Targets.valid(e, targetPlayers.get(), targetHostile.get(), targetPassive.get())) continue;
            LivingEntity living = (LivingEntity) e;
            if (mc.player.distanceTo(living) > targetRange.get()) continue;
            targets.add(living);
        }
        if (targets.isEmpty()) return;

        targets.sort(Comparator.comparingDouble(mc.player::distanceTo));
        int cap = maxTargets.getInt();
        for (int i = 0; i < targets.size() && i < cap; i++) {
            prepareFor(targets.get(i));
            emit(style.get());
        }
    }

    /** مثل Cosmetic.prepare()، لكن حول كيان ثاني بدل لاعبك. */
    private void prepareFor(LivingEntity target) {
        t = System.currentTimeMillis() / 1000.0;
        double yaw = Math.toRadians(target.bodyYaw);
        fx = -Math.sin(yaw);
        fz = Math.cos(yaw);
        rx = -Math.cos(yaw);
        rz = -Math.sin(yaw);
        ax = target.getX();
        ay = target.getY();
        az = target.getZ();
        height = target.getHeight();
        Vec3d v = target.getVelocity();
        pvx = v.x;
        pvy = v.y;
        pvz = v.z;
        speed = Math.sqrt(pvx * pvx + pvz * pvz);
        tick++;
    }

    // ------------------------------------------------------------ الستايلات (بدون تغيير)

    @Override
    protected void emit(String s) {
        double h = height;
        double sz = size.get();

        switch (s) {
            case "Spiral": {
                for (int k = 0; k < 2; k++) {
                    for (int j = 0; j < 10; j++) {
                        double f = j / 10.0;
                        double a = f * TAU * 2.0 + t * 2.5 + k * Math.PI;
                        put(Math.cos(a) * 0.55 * sz, f * h, Math.sin(a) * 0.55 * sz, col(f));
                    }
                }
                break;
            }
            case "Orbit": {
                for (int k = 0; k < 4; k++) {
                    double a = t * 2.0 + k * TAU / 4;
                    double y = h * 0.5 + 0.15 * Math.sin(t * 2.0 + k);
                    put(Math.cos(a) * 0.8 * sz, y, Math.sin(a) * 0.8 * sz, col(k / 4.0));
                    put(Math.cos(a) * 0.8 * sz, y + 0.04, Math.sin(a) * 0.8 * sz, col(k / 4.0));
                }
                break;
            }
            case "Shell": {
                int cnt = n(10);
                for (int i = 0; i < cnt; i++) sphere(0.95 * sz, h * 0.5, col(rnd()));
                break;
            }
            case "Pulse": {
                double r = (0.6 + 0.35 * (0.5 + 0.5 * Math.sin(t * 2.5))) * sz;
                int cnt = n(12);
                for (int i = 0; i < cnt; i++) sphere(r, h * 0.5, col(rnd()));
                break;
            }
            case "Flames": {
                int cnt = n(8);
                for (int i = 0; i < cnt; i++) {
                    double a = rnd() * TAU;
                    int c = Colors.lerp(col(rnd()), 0xFF7A18, 0.45);
                    putV(Math.cos(a) * 0.45 * sz, 0.05 + rnd() * 0.35, Math.sin(a) * 0.45 * sz, c, 0.0, 0.08, 0.0);
                }
                break;
            }
            case "Vortex": {
                for (int idx = 0; idx < 3; idx++) {
                    double dir = (idx % 2 == 0) ? 1.0 : -1.0;
                    hring(0, h * (0.3 + 0.25 * idx), 0, 0.6 * sz, 10, dir * t * 3.0, col(idx / 3.0));
                }
                break;
            }
            case "Electric": {
                int cnt = n(4);
                for (int i = 0; i < cnt; i++) {
                    double a = rnd() * TAU;
                    double bx = Math.cos(a) * 0.6 * sz;
                    double bz = Math.sin(a) * 0.6 * sz;
                    double by = rnd() * h;
                    int c = Colors.lerp(col(rnd()), 0xFFFFFF, 0.4);
                    for (int j = 0; j < 4; j++) {
                        put(bx + spread(0.12) * j, by + spread(0.12) * j, bz + spread(0.12) * j, c);
                    }
                }
                break;
            }
            case "Bubbles": {
                int cnt = n(5);
                for (int i = 0; i < cnt; i++) {
                    double a = rnd() * TAU;
                    double r = rnd() * 0.7 * sz;
                    putV(Math.cos(a) * r, rnd() * h, Math.sin(a) * r, col(rnd()), 0.0, 0.03, 0.0);
                }
                break;
            }
            case "Constellation": {
                double[] nx = new double[6];
                double[] ny = new double[6];
                double[] nz = new double[6];
                for (int k = 0; k < 6; k++) {
                    double a = t * 0.8 + k * TAU / 6;
                    nx[k] = Math.cos(a) * 0.9 * sz;
                    nz[k] = Math.sin(a) * 0.9 * sz;
                    ny[k] = h * 0.5 + 0.3 * Math.sin(k * 1.7 + t);
                    put(nx[k], ny[k], nz[k], 0xFFFFFF);
                }
                for (int k = 0; k < 6; k++) {
                    int m = (k + 1) % 6;
                    line(nx[k], ny[k], nz[k], nx[m], ny[m], nz[m], 3, col(k / 6.0));
                }
                break;
            }
            default: {
                // Rings
                for (int k = 0; k < 2; k++) {
                    double y = ((t * 0.8 + k * 0.5) % 1.0) * h;
                    hring(0, y, 0, (0.55 + 0.08 * Math.sin(t * 3.0)) * sz, 16, t, col(k / 2.0));
                }
                break;
            }
        }
    }
}
