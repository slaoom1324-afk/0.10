package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Sfx;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

import java.util.HashSet;
import java.util.Set;

public class PlayerAlert extends Module {
    private static final String[] DIRECTIONS = {"E", "SE", "S", "SW", "W", "NW", "N", "NE"};

    private final NumSetting range = num("Range", 30, 5, 200, 5, "Alert when a player comes closer than this (blocks)");
    private final BoolSetting sound = bool("Sound", true, "Play an alert sound");
    private final BoolSetting actionBar = bool("Action Bar", true, "Show the alert above your hotbar");
    private final BoolSetting chat = bool("Chat Log", false, "Also print the alert in chat");

    private final Set<Integer> inRange = new HashSet<>();

    public PlayerAlert() {
        super("PlayerAlert", Category.VISUAL, "Alerts you when a player gets close");
    }

    @Override
    protected void onEnable() {
        inRange.clear();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        double r = range.get();
        Set<Integer> still = new HashSet<>();

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isSpectator()) continue;
            double dist = mc.player.distanceTo(p);
            boolean known = inRange.contains(p.getId());

            // مسافة إضافية 5 بلوكات قبل ما نعتبره "طلع" عشان ما يتكرر التنبيه
            if (dist <= r || (known && dist <= r + 5)) {
                still.add(p.getId());
                if (!known) alert(p, dist);
            }
        }

        inRange.clear();
        inRange.addAll(still);
    }

    private String direction(PlayerEntity p) {
        double dx = p.getX() - mc.player.getX();
        double dz = p.getZ() - mc.player.getZ();
        int idx = (int) Math.round(Math.atan2(dz, dx) / (Math.PI / 4));
        return DIRECTIONS[((idx % 8) + 8) % 8];
    }

    private void alert(PlayerEntity p, double dist) {
        String text = p.getName().getString() + "  " + Math.round(dist) + "m " + direction(p);
        if (actionBar.get()) {
            mc.inGameHud.setOverlayMessage(Text.literal("Player nearby: " + text), false);
        }
        if (chat.get()) {
            mc.inGameHud.getChatHud().addMessage(Text.literal("[md5n] Player nearby: " + text));
        }
        if (sound.get()) Sfx.alert();
    }
}
