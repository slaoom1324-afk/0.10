package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.KeySetting;
import dev.md5n.setting.ModeSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Colors;
import dev.md5n.util.Neon;
import dev.md5n.util.Sfx;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class KillVfx extends Module {
    private static final String[] TYPES = {
            "Orbit", "Spiral", "Flare", "Constellation", "Satellite",
            "Storm", "Rift", "Shackles", "Singularity", "Swarm"
    };

    private final ModeSetting type = mode("Type", "Shackles",
            "Neon effect played when you kill someone. Random picks a different one each kill",
            "Orbit", "Spiral", "Flare", "Constellation", "Satellite",
            "Storm", "Rift", "Shackles", "Singularity", "Swarm", "Random");
    private final ModeSetting palette = mode("Palette", "Neon Pink", "Colors of the effect (Theme follows your menu color)",
            "Neon Pink", "Neon Purple", "Cyan", "Gold", "Theme", "Rainbow");
    private final NumSetting intensity = num("Intensity", 1.0, 0.5, 3.0, 0.1, "How dense the effect is");
    private final BoolSetting sound = bool("Sound", true, "Play a small jingle with the effect");
    private final BoolSetting includeMobs = bool("Include Mobs", false, "Also play the effect when you kill mobs");
    private final KeySetting testKey = keybind("Test Key", GLFW.GLFW_KEY_J, "Press to preview the effect in front of you");

    private static final class Track {
        int lastAttack;
        Vec3d pos;
        float health;
    }

    private final Map<Integer, Track> tracks = new HashMap<>();
    private int tickCount;

    public KillVfx() {
        super("Kill VFX", Category.VFX, "Custom neon animations when you kill a player");

        // نسجّل آخر كيان ضربته، ونراقبه لين يموت
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (player == mc.player) onAttack(entity);
            return ActionResult.PASS;
        });
    }

    @Override
    protected void onDisable() {
        tracks.clear();
    }

    private void onAttack(Entity entity) {
        if (!isEnabled()) return;
        if (!(entity instanceof LivingEntity living)) return;
        boolean isPlayer = entity instanceof PlayerEntity;
        if (!isPlayer && !includeMobs.get()) return;

        Track t = tracks.computeIfAbsent(entity.getId(), k -> new Track());
        t.lastAttack = tickCount;
        t.pos = living.getPos();
        t.health = living.getHealth();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tickCount++;

        if (mc.currentScreen == null && testKey.consumePress(mc.getWindow().getHandle())) {
            Vec3d look = mc.player.getRotationVec(1.0f);
            start(mc.player.getPos().add(look.x * 3.0, 0.0, look.z * 3.0));
        }

        Iterator<Map.Entry<Integer, Track>> it = tracks.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Track> en = it.next();
            Track t = en.getValue();
            Entity e = mc.world.getEntityById(en.getKey());

            if (e instanceof LivingEntity living) {
                if (living.isDead() || living.getHealth() <= 0f) {
                    start(living.getPos());
                    it.remove();
                    continue;
                }
                t.pos = living.getPos();
                t.health = living.getHealth();
            } else if (e == null && tickCount - t.lastAttack <= 40 && t.health <= 6f && t.pos != null) {
                start(t.pos);
                it.remove();
                continue;
            }

            if (tickCount - t.lastAttack > 100) it.remove();
        }
    }

    private void start(Vec3d pos) {
        String chosen = type.get();
        if (chosen.equals("Random")) {
            chosen = TYPES[ThreadLocalRandom.current().nextInt(TYPES.length)];
        }
        Neon.addEffect(new Show(pos, chosen));
        if (sound.get()) {
            if (chosen.equals("Storm") || chosen.equals("Singularity") || chosen.equals("Rift")) {
                Sfx.note(0.5f);
                Sfx.note(0.56f);
                Sfx.note(0.63f);
            } else {
                Sfx.note(1.0f);
                Sfx.note(1.26f);
                Sfx.note(1.5f);
            }
        }
    }

    private int paletteColor(double phase) {
        switch (palette.get()) {
            case "Neon Purple": return phase < 0.5 ? 0xB06BFF : 0xE6D2FF;
            case "Cyan": return phase < 0.5 ? 0x4DE8FF : 0xDDFBFF;
            case "Gold": return phase < 0.5 ? 0xFFC53D : 0xFFF1C2;
            case "Theme": {
                int c = Colors.theme();
                return phase < 0.5 ? c : Colors.lerp(c, 0xFFFFFF, 0.6);
            }
            case "Rainbow": return Colors.hsv((System.currentTimeMillis() / 4000.0 + phase) % 1.0, 0.6, 1.0);
            default: return phase < 0.5 ? 0xFF7AE0 : 0xFFE3F8;
        }
    }

    // ------------------------------------------------------------ المؤثر نفسه
    private final class Show implements Neon.Effect {
        private final double x, y, z, seed;
        private final String kind;
        private final int life;
        private final int c1, c2;
        private int age;

        Show(Vec3d pos, String kind) {
            this.x = pos.x;
            this.y = pos.y;
            this.z = pos.z;
            this.kind = kind;
            this.seed = Neon.rnd() * 100.0;
            this.life = kind.equals("Singularity") ? 70 : 56;
            this.c1 = paletteColor(0.0);
            this.c2 = paletteColor(0.9);
        }

        @Override
        public boolean tick() {
            age++;
            return age < life;
        }

        @Override
        public void render(Neon.Painter p, double partial) {
            double ft = age + partial;
            double f = ft / life;
            double t = ft / 20.0;
            double env = Math.min(1.0, f / 0.12) * Math.min(1.0, (1.0 - f) / 0.25);
            if (env <= 0.01) return;
            double k = Math.max(0.5, intensity.get());
            double cy = y + 1.0;

            switch (kind) {
                case "Orbit": {
                    double[] c = Neon.v(x, cy, z);
                    for (int r = 0; r < 3; r++) {
                        double tilt = 0.5 + r * 0.55;
                        double spin = t * (1.1 + r * 0.4) + r * 2.1 + seed;
                        double[] u = Neon.rotY(1.0, 0.0, 0.0, spin);
                        double[] vv = Neon.rotY(0.0, Math.sin(tilt), Math.cos(tilt), spin);
                        double rad = (0.75 + r * 0.18) * Math.min(1.0, f * 5.0);
                        int col = (r % 2 == 0) ? c1 : c2;
                        p.loop(c, u, vv, rad, rad, 36, col, 0.8 * env, 0.012, true);
                        double ang = t * (2.4 + r * 0.6) + r;
                        for (int tr = 0; tr < 6; tr++) {
                            double a2 = ang - tr * 0.18;
                            double[] pt = Neon.add(c, Neon.add(Neon.mul(u, Math.cos(a2) * rad), Neon.mul(vv, Math.sin(a2) * rad)));
                            p.orb(pt, 0.05 * (1.0 - tr * 0.12), col, env * (1.0 - tr * 0.15));
                        }
                    }
                    break;
                }
                case "Spiral": {
                    int n = (int) Math.max(4, Math.min(28, 28 * Math.min(1.0, f * 4.0)));
                    for (int arm = 0; arm < 2; arm++) {
                        int col = (arm == 0) ? c1 : c2;
                        double[] prev = null;
                        for (int i = 0; i <= n; i++) {
                            double s = i / 28.0;
                            double a = s * Neon.TAU * 2.0 + t * 3.0 + arm * Math.PI + seed;
                            double r = 0.55 * (1.0 - 0.35 * s);
                            double[] pt = Neon.v(x + Math.cos(a) * r, y + 0.1 + s * 2.0, z + Math.sin(a) * r);
                            if (prev != null) p.line(prev, pt, col, 0.7 * env, 0.012);
                            p.orb(pt, 0.025 + 0.02 * (1.0 - s), col, env * 0.9);
                            prev = pt;
                        }
                    }
                    double br = 0.3 + f * 1.6;
                    p.loop(Neon.v(x, y + 0.05, z), Neon.v(1, 0, 0), Neon.v(0, 0, 1), br, br, 30, c1, 0.5 * env * (1.0 - f), 0.01, false);
                    break;
                }
                case "Flare": {
                    double fl = Math.min(1.0, f * 2.2);
                    double[] c = Neon.v(x, cy, z);
                    for (int i = 0; i < 14; i++) {
                        double[] d = Neon.unit(seed + i * 3.1);
                        double r1 = fl * (1.4 + 1.2 * Neon.hash(seed + i + 100.0));
                        double r0 = r1 * 0.35;
                        p.line(Neon.add(c, Neon.mul(d, r0)), Neon.add(c, Neon.mul(d, r1)),
                                (i % 2 == 0) ? c1 : 0xFFFFFF, env * 0.9, 0.014);
                    }
                    p.orb(c, 0.25 * (1.0 - f) + 0.05, 0xFFFFFF, env * 1.1);
                    double gr = f * 2.4;
                    p.loop(Neon.v(x, y + 0.05, z), Neon.v(1, 0, 0), Neon.v(0, 0, 1), gr, gr, 32, c2, 0.6 * env * (1.0 - f), 0.012, false);
                    break;
                }
                case "Constellation": {
                    int m = 8;
                    double[][] st = new double[m][];
                    for (int i = 0; i < m; i++) {
                        double[] d = Neon.unit(seed + i * 7.7);
                        double rad = 0.7 + 0.5 * Neon.hash(seed + i + 20.0);
                        double ang = Math.atan2(d[2], d[0]) + t * 0.35;
                        st[i] = Neon.v(x + Math.cos(ang) * rad, cy + (Neon.hash(seed + i + 40.0) - 0.5) * 1.6, z + Math.sin(ang) * rad);
                        p.orb(st[i], 0.04 + 0.015 * Math.sin(t * 4.0 + i), (i % 2 == 0) ? 0xFFFFFF : c1, env);
                    }
                    for (int i = 0; i < m - 1; i++) {
                        double reveal = Math.max(0.0, Math.min(1.0, f * 4.0 - i * 0.35));
                        if (reveal > 0.0) p.line(st[i], Neon.lerp(st[i], st[i + 1], reveal), c2, 0.65 * env, 0.008);
                    }
                    p.line(st[0], st[4], c2, 0.35 * env, 0.006);
                    p.line(st[2], st[6], c2, 0.35 * env, 0.006);
                    break;
                }
                case "Satellite": {
                    double[] c = Neon.v(x, cy, z);
                    double tilt = 0.9;
                    double spin = t * 0.9 + seed;
                    double[] u = Neon.rotY(1.0, 0.0, 0.0, spin);
                    double[] vv = Neon.rotY(0.0, Math.sin(tilt), Math.cos(tilt), spin);
                    double rad = Math.min(1.0, f * 5.0);
                    for (int i = 0; i < 30; i++) {
                        double a = i * Neon.TAU / 30.0;
                        p.orb(Neon.add(c, Neon.add(Neon.mul(u, Math.cos(a) * rad), Neon.mul(vv, Math.sin(a) * rad))), 0.012, c1, 0.4 * env);
                    }
                    double sa = t * 2.6;
                    double[] sp = Neon.add(c, Neon.add(Neon.mul(u, Math.cos(sa) * rad), Neon.mul(vv, Math.sin(sa) * rad)));
                    double[] tangent = Neon.norm(Neon.add(Neon.mul(u, -Math.sin(sa)), Neon.mul(vv, Math.cos(sa))));
                    p.orb(sp, 0.07, 0xFFFFFF, env);
                    p.line(Neon.add(sp, Neon.mul(tangent, 0.14)), Neon.add(sp, Neon.mul(tangent, -0.14)), c2, 0.9 * env, 0.02);
                    p.line(Neon.add(sp, Neon.mul(vv, 0.1)), Neon.add(sp, Neon.mul(vv, -0.1)), c1, 0.8 * env, 0.012);
                    double ma = -t * 3.8;
                    p.orb(x + Math.cos(ma) * 0.45, cy + 0.2 * Math.sin(ma * 2.0), z + Math.sin(ma) * 0.45, 0.035, c2, env);
                    break;
                }
                case "Storm": {
                    double cloudY = y + 2.7;
                    for (int i = 0; i < 16; i++) {
                        double a = i / 16.0 * Neon.TAU + t * 0.8;
                        double r = 0.35 + 0.45 * Neon.hash(seed + i);
                        p.cloud(x + Math.cos(a) * r, cloudY + 0.12 * Math.sin(t * 2.0 + i), z + Math.sin(a) * r, 0.55, 0x6A4BA8, 0.9 * env);
                    }
                    for (int b = 0; b < 3; b++) {
                        double phase = Math.floor(t * 6.0 + b * 7.0);
                        if (Neon.hash(phase + b * 13.0 + seed) < 0.55) continue;
                        double[] prev = Neon.v(x + (Neon.hash(phase + b) - 0.5) * 0.6, cloudY - 0.2,
                                z + (Neon.hash(phase + b + 5.0) - 0.5) * 0.6);
                        for (int s = 1; s <= 7; s++) {
                            double f2 = s / 7.0;
                            double[] nx = Neon.v(
                                    x + (Neon.hash(phase * 3.0 + b * 11.0 + s) - 0.5) * 0.7 * (1.0 - f2),
                                    cloudY - 0.2 - f2 * (cloudY - 0.2 - y - 0.05),
                                    z + (Neon.hash(phase * 5.0 + b * 17.0 + s) - 0.5) * 0.7 * (1.0 - f2));
                            p.line(prev, nx, (b % 2 == 0) ? 0xFFFFFF : c2, env, 0.02);
                            prev = nx;
                        }
                        p.orb(x, y + 0.1, z, 0.18, c1, env);
                    }
                    for (int i = 0; i < 10; i++) {
                        double rx = x + (Neon.hash(seed + i * 2.0) - 0.5) * 1.6;
                        double rz = z + (Neon.hash(seed + i * 2.0 + 1.0) - 0.5) * 1.6;
                        double ry = y + 2.4 - ((t * 3.0 + Neon.hash(seed + i)) % 1.0) * 2.4;
                        p.line(rx, ry, rz, rx, ry - 0.25, rz, c2, 0.4 * env, 0.006);
                    }
                    break;
                }
                case "Rift": {
                    double open = Math.min(1.0, f * 4.0) * Math.min(1.0, (1.0 - f) * 4.0);
                    double[] c = Neon.v(x, y + 1.1, z);
                    double[] u = Neon.v(Math.cos(seed), 0.0, Math.sin(seed));
                    double[] vv = Neon.v(0.0, 1.0, 0.0);
                    double a = 0.35 * open;
                    double b = 1.15 * open;
                    p.loop(c, u, vv, a, b, 32, c1, 0.9 * env, 0.016, true);
                    p.loop(c, u, vv, a * 0.6, b * 0.8, 28, c2, 0.6 * env, 0.01, true);
                    for (int j = -4; j <= 4; j++) {
                        p.orb(Neon.add(c, Neon.mul(vv, j * b / 5.0)), 0.12 * (1.0 - Math.abs(j) / 5.0) * open + 0.01, c2, env * 0.4);
                    }
                    for (int i = 0; i < 8; i++) {
                        double ang = i * Neon.TAU / 8.0 + 0.3;
                        double[] edge = Neon.add(c, Neon.add(Neon.mul(u, Math.cos(ang) * a), Neon.mul(vv, Math.sin(ang) * b)));
                        double[] mid = Neon.add(Neon.lerp(c, edge, 0.5), Neon.mul(u, (Neon.hash(seed + i + 3.0) - 0.5) * 0.12));
                        p.line(c, mid, c1, 0.5 * env, 0.008);
                        p.line(mid, edge, c2, 0.5 * env, 0.008);
                    }
                    for (int i = 0; i < 6; i++) {
                        double ang = t * 1.5 + i * Neon.TAU / 6.0;
                        p.orb(Neon.add(c, Neon.add(Neon.mul(u, Math.cos(ang) * a), Neon.mul(vv, Math.sin(ang) * b))), 0.035, 0xFFFFFF, env);
                    }
                    break;
                }
                case "Singularity": {
                    double collapse = Math.min(1.0, f / 0.6);
                    double[] c = Neon.v(x, cy, z);
                    int n = (int) Math.min(48, 30 + 8 * k);
                    for (int i = 0; i < n; i++) {
                        double[] d = Neon.unit(seed + i * 2.3);
                        double rr = (2.4 * (1.0 - collapse) + 0.12) * (0.7 + 0.5 * Neon.hash(seed + i + 7.0));
                        double[] head = Neon.add(c, Neon.mul(d, rr));
                        double[] tail = Neon.add(c, Neon.mul(d, rr + 0.5 * (1.0 - collapse) + 0.1));
                        int col = (i % 2 == 0) ? c1 : c2;
                        double fade = f < 0.6 ? 1.0 : Math.max(0.0, 1.0 - (f - 0.6) * 5.0);
                        p.line(head, tail, col, env * 0.8 * fade, 0.01);
                    }
                    double coreR = 0.12 + 0.05 * Math.sin(t * 14.0) + 0.08 * collapse;
                    p.orb(c, coreR, 0xFFFFFF, env);
                    p.orb(c, coreR * 2.2, c1, env * 0.6);
                    double[] u = Neon.rotY(1.0, 0.0, 0.0, t * 3.0);
                    double[] vv = Neon.rotY(0.0, 0.3, 1.0, t * 3.0);
                    double ring = 0.5 * (1.0 - collapse) + 0.15;
                    p.loop(c, u, vv, ring, ring, 30, c2, 0.8 * env, 0.012, true);
                    if (f > 0.6) {
                        double sf = (f - 0.6) / 0.4;
                        double wave = sf * 2.6;
                        p.loop(c, Neon.v(1, 0, 0), Neon.v(0, 0, 1), wave, wave, 36, c1, 0.8 * env * (1.0 - sf), 0.016, false);
                    }
                    break;
                }
                case "Swarm": {
                    int n = (int) Math.min(24, 14 + 4 * k);
                    double wide = 0.5 + 0.8 * Math.min(1.0, f * 3.0);
                    for (int i = 0; i < n; i++) {
                        double w1 = 1.3 + Neon.hash(seed + i) * 1.6;
                        double w2 = 1.1 + Neon.hash(seed + i + 30.0) * 1.5;
                        double w3 = 1.0 + Neon.hash(seed + i + 60.0) * 1.7;
                        double ph = Neon.hash(seed + i + 90.0) * Neon.TAU;
                        int col = (i % 2 == 0) ? c1 : c2;
                        for (int tr = 0; tr < 5; tr++) {
                            double tt = t - tr * 0.045;
                            p.orb(x + Math.sin(w1 * tt + ph) * wide,
                                    cy + Math.cos(w2 * tt + ph * 0.7) * 0.7 * wide,
                                    z + Math.sin(w3 * tt + ph * 1.3) * wide,
                                    0.04 * (1.0 - tr * 0.15), col, env * (1.0 - tr * 0.2));
                        }
                    }
                    break;
                }
                default: {
                    // Shackles: سلاسل نيون تلتف حول الهدف
                    int links = 16;
                    double reveal = Math.min(1.0, f * 3.0);
                    double drop = f > 0.82 ? (f - 0.82) / 0.18 : 0.0;
                    for (int ch = 0; ch < 2; ch++) {
                        for (int i = 0; i < links; i++) {
                            if (i / (double) links > reveal) break;
                            double s = (i + 0.5) / links;
                            double a0 = s * Neon.TAU * 1.5 + t * 1.3 + ch * Math.PI + seed;
                            double r0 = 0.62 + 0.08 * Math.sin(s * 9.0 + t);
                            double yy = y + 0.15 + s * 1.5 - drop * 0.6 * s;
                            double[] c = Neon.v(x + Math.cos(a0) * r0, yy, z + Math.sin(a0) * r0);
                            double[] tangent = Neon.norm(Neon.v(-r0 * Math.sin(a0), 0.159, r0 * Math.cos(a0)));
                            double[] radial = Neon.v(Math.cos(a0), 0.0, Math.sin(a0));
                            double[] vv = (i % 2 == 0) ? radial : Neon.norm(Neon.cross(tangent, radial));
                            double al = env * (1.0 - drop);
                            p.loop(c, tangent, vv, 0.12, 0.065, 14, c1, 0.9 * al, 0.013, true);
                            p.loop(c, tangent, vv, 0.085, 0.04, 12, c2, 0.55 * al, 0.007, true);
                            if (i % 4 == 0) p.orb(c, 0.03, 0xFFFFFF, al * 0.8);
                        }
                    }
                    break;
                }
            }
        }
    }
}
