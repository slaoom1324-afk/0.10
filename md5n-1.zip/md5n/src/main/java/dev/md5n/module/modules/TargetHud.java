package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Draw;
import dev.md5n.util.Targets;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;

/**
 * بطاقة معلومات صغيرة تثبت بجانب الهدف اللي تقاتله: اسمه وصحته (شريط متحرك)
 * ومسافته وسلاحه، مع صف سفلي فيه الكومبو وعدد الضربات وفرق الارتفاع.
 * كل شي يُرسم فوق الشاشة (2D)، ما فيه أي كيان ثلاثي الأبعاد جديد.
 */
public class TargetHud extends Module {
    private final NumSetting range = num("Range", 20, 5, 60, 1, "Max distance to keep showing the card");
    private final BoolSetting players = bool("Players", true, "Track players");
    private final BoolSetting hostile = bool("Hostile", true, "Track hostile mobs");
    private final BoolSetting passive = bool("Passive", false, "Track animals and villagers");
    private final BoolSetting showWeapon = bool("Weapon Tag", true, "Show the target's held item (players only)");
    private final NumSetting offsetX = num("Offset X", 0, -60, 60, 1, "Pixels to shift the card left/right");
    private final NumSetting offsetY = num("Offset Y", -34, -100, 20, 1, "Pixels to shift the card up/down");
    private final NumSetting comboWindow = num("Combo Window (s)", 1.5, 0.5, 5.0, 0.1, "Combo resets if you miss for this long");
    private final NumSetting lingerTime = num("Linger (s)", 3.0, 0.5, 8.0, 0.5, "How long the card stays after combat stops");
    private final NumSetting healthSpeed = num("Health Bar Speed", 0.25, 0.05, 1.0, 0.05, "How fast the health bar catches up");

    private static final int CARD_W = 168;
    private static final int ROW1_Y = 6;
    private static final int BAR_Y = 24;
    private static final int ROW2_Y = 32;
    private static final int CARD_H = 50;

    private int targetId = -1;
    private int combo;
    private int hitsLanded;
    private int hitsAttempted;
    private int lastHitTick;
    private boolean attackWasDown;
    private double displayedHealthFrac = 1.0;
    private int tickCount;

    public TargetHud() {
        super("TargetHUD", Category.COMBAT, "A small card pinned beside whoever you're fighting");

        // كل ضربة ناجحة على كيان صالح تسجّل الهدف وتحدّث الكومبو
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (player == mc.player) onAttack(entity);
            return ActionResult.PASS;
        });
    }

    @Override
    protected void onDisable() {
        targetId = -1;
    }

    private void onAttack(Entity entity) {
        if (!isEnabled()) return;
        if (!Targets.valid(entity, players.get(), hostile.get(), passive.get())) return;

        if (entity.getId() != targetId) {
            targetId = entity.getId();
            combo = 0;
            hitsLanded = 0;
            hitsAttempted = 0;
            displayedHealthFrac = 1.0;
        }
        combo++;
        hitsLanded++;
        hitsAttempted = Math.max(hitsAttempted, hitsLanded);
        lastHitTick = tickCount;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            targetId = -1;
            return;
        }
        tickCount++;

        // نعدّ محاولات الهجوم (ضغطات زر الهجوم) طالما عندنا هدف، عشان "landed-attempted"
        boolean attackDown = mc.currentScreen == null && mc.options.attackKey.isPressed();
        if (attackDown && !attackWasDown && targetId != -1) {
            hitsAttempted++;
            hitsAttempted = Math.max(hitsAttempted, hitsLanded);
        }
        attackWasDown = attackDown;

        if (targetId == -1) return;

        Entity e = mc.world.getEntityById(targetId);
        if (!(e instanceof LivingEntity target) || !target.isAlive()
                || mc.player.distanceTo(target) > range.get()) {
            if (tickCount - lastHitTick > lingerTime.get() * 20.0) {
                targetId = -1;
            }
            return;
        }

        if (tickCount - lastHitTick > comboWindow.get() * 20.0) combo = 0;
        if (tickCount - lastHitTick > lingerTime.get() * 20.0) {
            targetId = -1;
            return;
        }

        double frac = target.getMaxHealth() > 0f ? target.getHealth() / target.getMaxHealth() : 0.0;
        frac = Math.max(0.0, Math.min(1.0, frac));
        displayedHealthFrac += (frac - displayedHealthFrac) * healthSpeed.get();
    }

    // ------------------------------------------------------------ الإسقاط على الشاشة

    private boolean project(DrawContext ctx, double x, double y, double z, double[] out) {
        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null) return false;
        Vec3d pos = cam.getPos();
        double dx = x - pos.x, dy = y - pos.y, dz = z - pos.z;

        double yaw = Math.toRadians(cam.getYaw());
        double pitch = Math.toRadians(cam.getPitch());
        double cosY = Math.cos(yaw), sinY = Math.sin(yaw), cosP = Math.cos(pitch), sinP = Math.sin(pitch);
        double fx = -sinY * cosP, fy = -sinP, fz = cosY * cosP;
        double rx = -cosY, rz = -sinY;
        double ux = -sinY * sinP, uy = cosP, uz = cosY * sinP;

        double zc = dx * fx + dy * fy + dz * fz;
        if (zc < 0.15) return false;
        double xc = dx * rx + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;

        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        double fov = Math.max(30.0, Math.min(140.0, mc.options.getFov().getValue()));
        double scale = (h / 2.0) / Math.tan(Math.toRadians(fov) / 2.0);

        out[0] = w / 2.0 + xc / zc * scale;
        out[1] = h / 2.0 - yc / zc * scale;
        out[2] = zc;
        return true;
    }

    // ------------------------------------------------------------ الرسم

    @Override
    public void onHudRender(DrawContext ctx) {
        if (mc.player == null || mc.world == null || targetId == -1) return;

        Entity e = mc.world.getEntityById(targetId);
        if (!(e instanceof LivingEntity target) || !target.isAlive()) return;

        double[] screen = new double[3];
        boolean onScreen = project(ctx, target.getX(), target.getY() + target.getHeight() + 0.25, target.getZ(), screen);
        if (!onScreen) return;

        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        int cardX = (int) Math.round(screen[0] - CARD_W / 2.0 + offsetX.get());
        int cardY = (int) Math.round(screen[1] + offsetY.get());
        cardX = Math.max(2, Math.min(w - CARD_W - 2, cardX));
        cardY = Math.max(2, Math.min(h - CARD_H - 2, cardY));

        ThemeSettings theme = dev.md5n.Md5n.modules.get(ThemeSettings.class);
        int accent = theme == null ? 0xFF55FFFF : theme.accent();
        int fill = theme == null ? 0xDD101018 : Draw.alpha(theme.header(), 0.86f);
        int border = Draw.alpha(accent, 0.55f);
        int glow = Draw.alpha(accent, 0.08f);

        Draw.glass(ctx, cardX, cardY, cardX + CARD_W, cardY + CARD_H, 6, fill, border, glow);

        var tr = mc.textRenderer;
        int textX = cardX + 8;

        // صف 1: أفاتار (حرف أول) + الاسم ................ سلاح الهدف
        int avatarSize = 14;
        int avatarColor = (target instanceof PlayerEntity) ? accent : 0xFFB04040;
        Draw.roundRect(ctx, textX, cardY + ROW1_Y - 2, textX + avatarSize, cardY + ROW1_Y - 2 + avatarSize, 3, 0xFF000000 | (avatarColor & 0xFFFFFF));
        String initial = target.getName().getString().isEmpty() ? "?" : target.getName().getString().substring(0, 1).toUpperCase(Locale.ROOT);
        ctx.drawTextWithShadow(tr, initial, textX + avatarSize / 2 - tr.getWidth(initial) / 2, cardY + ROW1_Y + 1, 0xFFFFFFFF);

        String name = trim(tr, target.getName().getString(), 78);
        ctx.drawTextWithShadow(tr, name, textX + avatarSize + 5, cardY + ROW1_Y + 2, 0xFFFFFFFF);

        if (showWeapon.get() && target instanceof PlayerEntity targetPlayer) {
            ItemStack weapon = targetPlayer.getMainHandStack();
            String tag = weapon.isEmpty() ? "Unarmed" : trim(tr, weapon.getName().getString(), 60);
            int tagW = tr.getWidth(tag) + (weapon.isEmpty() ? 6 : 20);
            int tagX = cardX + CARD_W - 6 - tagW;
            Draw.roundRect(ctx, tagX, cardY + ROW1_Y - 2, tagX + tagW, cardY + ROW1_Y - 2 + 12, 3, Draw.alpha(accent, 0.30f));
            int tx = tagX + 3;
            if (!weapon.isEmpty()) {
                ctx.drawItem(weapon, tagX + 2, cardY + ROW1_Y - 6);
                tx += 15;
            }
            ctx.drawTextWithShadow(tr, tag, tx, cardY + ROW1_Y + 1, 0xFFFFFFFF);
        }

        // صف 2: قلب + صحة ................ المسافة
        float health = Math.max(0f, target.getHealth());
        String hp = "\u2764 " + (Math.round(health * 10f) / 10f);
        ctx.drawTextWithShadow(tr, hp, textX, cardY + ROW2_Y, 0xFFFF6B6B);

        double dist = mc.player.distanceTo(target);
        String distTxt = String.format(Locale.ROOT, "%.1f m", dist);
        ctx.drawTextWithShadow(tr, distTxt, cardX + CARD_W - 6 - tr.getWidth(distTxt), cardY + ROW2_Y, 0xFFCCCCCC);

        // شريط الصحة المتحرك
        int barX = textX, barY = cardY + BAR_Y, barW = CARD_W - 16, barH = 4;
        Draw.roundRect(ctx, barX, barY, barX + barW, barY + barH, 2, 0x55000000);
        int filled = (int) Math.round(barW * displayedHealthFrac);
        int barColor = Draw.lerp(0xFFFF4D4D, 0xFF4DFFA0, (float) displayedHealthFrac);
        if (filled > 0) Draw.roundRect(ctx, barX, barY, barX + filled, barY + barH, 2, 0xFF000000 | (barColor & 0xFFFFFF));

        // الصف السفلي: كومبو | ضربات | فرق الارتفاع
        int botY = cardY + CARD_H - 13;
        String comboTxt = combo + " combo";
        String hitsTxt = hitsLanded + "-" + hitsAttempted + " hits";
        int heightDiff = (int) Math.round(target.getY() - mc.player.getY());
        String relTxt = heightDiff == 0 ? "level" : (heightDiff < 0 ? Math.abs(heightDiff) + " below" : heightDiff + " above");

        int slot = (CARD_W - 12) / 3;
        drawChip(ctx, textX, botY, slot - 3, comboTxt, accent);
        drawChip(ctx, textX + slot, botY, slot - 3, hitsTxt, 0xFFCCCCCC);
        drawChip(ctx, textX + slot * 2, botY, slot - 3, relTxt, heightDiff < 0 ? 0xFFFF8A65 : 0xFF8AD1FF);
    }

    private void drawChip(DrawContext ctx, int x, int y, int w, String text, int color) {
        var tr = mc.textRenderer;
        Draw.roundRect(ctx, x, y - 2, x + w, y + 9, 3, 0x40000000);
        String shown = trim(tr, text, w - 4);
        ctx.drawTextWithShadow(tr, shown, x + Math.max(2, (w - tr.getWidth(shown)) / 2), y, color);
    }

    private static String trim(net.minecraft.client.font.TextRenderer tr, String text, int maxWidth) {
        return tr.getWidth(text) <= maxWidth ? text : tr.trimToWidth(text, Math.max(0, maxWidth - tr.getWidth("..")))+ "..";
    }
}
