package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Colors;
import dev.md5n.util.Neon;

import java.util.concurrent.ThreadLocalRandom;

public class Ambiance extends Module {
    private final NumSetting radius = num("Radius", 12, 4, 24, 1, "How far around you the effects spawn");
    private final NumSetting intensity = num("Intensity", 1.0, 0.2, 3.0, 0.1, "How many motes spawn");
    private final BoolSetting outdoorsOnly = bool("Outdoors Only", true, "Falling effects only when you can see the sky");
    private final BoolSetting themeTint = bool("Theme Tint", false, "Blend every effect with your Theme color");

    private final BoolSetting fireflies = bool("Fireflies", true, "Blinking glowing dots drifting near the ground");
    private final BoolSetting sparkles = bool("Sparkles", true, "Twinkling stars floating upward");
    private final BoolSetting snow = bool("Snowfall", false, "Six-armed snowflakes falling gently");
    private final BoolSetting petals = bool("Cherry Petals", false, "Pink petals swaying down");
    private final BoolSetting embers = bool("Embers", false, "Warm embers rising from the ground");
    private final BoolSetting ash = bool("Ash Fall", false, "Grey flecks slowly falling");
    private final BoolSetting spores = bool("Spores", false, "Teal and red rings floating around");
    private final BoolSetting souls = bool("Soul Wisps", false, "Blue wisps rising like ghosts");
    private final BoolSetting magic = bool("Magic Glyphs", false, "Glowing runes drifting around you");
    private final BoolSetting mist = bool("Mist", false, "Low soft mist near the ground");
    private final BoolSetting dragon = bool("Dragon Breath", false, "Purple haze hugging the ground");
    private final BoolSetting voidDust = bool("Void Dust", false, "Violet streaks drifting through the air");

    public Ambiance() {
        super("Ambiance", Category.VFX, "Custom atmospheric effects around you: fireflies, snow, embers and more");
    }

    private static double rnd() {
        return ThreadLocalRandom.current().nextDouble();
    }

    private static double spread(double range) {
        return (rnd() * 2.0 - 1.0) * range;
    }

    private static int life(int base, int var) {
        return base + (int) (rnd() * var);
    }

    private int count(double rate) {
        double v = rate * intensity.get();
        int n = (int) v;
        if (rnd() < v - n) n++;
        return n;
    }

    private Neon.P mote(int kind, double x, double y, double z, double vx, double vy, double vz,
                        int life, double size, int rgb) {
        int c = themeTint.get() ? Colors.lerp(rgb, Colors.theme(), 0.45) : rgb;
        return Neon.spawn(kind, x, y, z, vx, vy, vz, life, size, c);
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;

        double px = mc.player.getX();
        double py = mc.player.getY();
        double pz = mc.player.getZ();
        double r = radius.get();
        boolean sky = !outdoorsOnly.get() || mc.world.isSkyVisible(mc.player.getBlockPos());

        if (fireflies.get()) {
            int n = count(0.35);
            for (int i = 0; i < n; i++) {
                Neon.P p = mote(Neon.ORB, px + spread(r), py - 0.5 + rnd() * 3.5, pz + spread(r),
                        spread(0.012), spread(0.008), spread(0.012), life(60, 70), 0.05, 0xE8FF7A);
                p.twinkle = true;
                p.drag = 0.985;
            }
        }
        if (sparkles.get()) {
            int n = count(0.5);
            for (int i = 0; i < n; i++) {
                Neon.P p = mote(Neon.SPARK, px + spread(r), py + rnd() * 4.0, pz + spread(r),
                        spread(0.004), 0.01 + rnd() * 0.02, spread(0.004), life(40, 40), 0.045, 0xE6F4FF);
                p.twinkle = true;
                p.drag = 1.0;
            }
        }
        if (snow.get() && sky) {
            int n = count(2.0);
            for (int i = 0; i < n; i++) {
                Neon.P p = mote(Neon.FLAKE, px + spread(r), py + 6.0 + rnd() * 5.0, pz + spread(r),
                        0.0, -0.07 - rnd() * 0.03, 0.0, 110, 0.045, 0xF4FAFF);
                p.drag = 1.0;
                p.sway = 0.004;
            }
        }
        if (petals.get() && sky) {
            int n = count(0.8);
            for (int i = 0; i < n; i++) {
                Neon.P p = mote(Neon.PETAL, px + spread(r), py + 5.0 + rnd() * 6.0, pz + spread(r),
                        0.0, -0.03, 0.0, 150, 0.06, 0xFFB7D5);
                p.drag = 1.0;
                p.sway = 0.006;
            }
        }
        if (embers.get()) {
            int n = count(0.6);
            for (int i = 0; i < n; i++) {
                Neon.P p = mote(Neon.ORB, px + spread(r), py + rnd() * 2.0, pz + spread(r),
                        spread(0.01), 0.05 + rnd() * 0.03, spread(0.01), life(30, 20), 0.03, 0xFF8A2B);
                p.twinkle = true;
                p.drag = 0.99;
            }
        }
        if (ash.get() && sky) {
            int n = count(1.5);
            for (int i = 0; i < n; i++) {
                Neon.P p = mote(Neon.SPECK, px + spread(r), py + 2.0 + rnd() * 6.0, pz + spread(r),
                        0.0, -0.025, 0.0, 120, 0.035, rnd() < 0.7 ? 0xB8B8B8 : 0xE6E6E6);
                p.drag = 1.0;
                p.sway = 0.003;
            }
        }
        if (spores.get()) {
            int n = count(1.0);
            for (int i = 0; i < n; i++) {
                Neon.P p = mote(Neon.RING, px + spread(r), py + rnd() * 3.0, pz + spread(r),
                        spread(0.01), -0.005, spread(0.01), life(70, 30), 0.045, rnd() < 0.55 ? 0x3FE0C9 : 0xE0405A);
                p.drag = 0.99;
            }
        }
        if (souls.get()) {
            int n = count(0.3);
            for (int i = 0; i < n; i++) {
                Neon.P p = mote(Neon.WISP, px + spread(r), py + rnd() * 2.0, pz + spread(r),
                        0.0, 0.03, 0.0, life(60, 30), 0.08, 0x7FE8FF);
                p.drag = 1.0;
            }
        }
        if (magic.get()) {
            int n = count(0.8);
            for (int i = 0; i < n; i++) {
                Neon.P p = mote(Neon.RUNE, px + spread(3.5), py + 0.5 + rnd() * 2.5, pz + spread(3.5),
                        spread(0.004), 0.02, spread(0.004), life(50, 30), 0.07, 0xC79BFF);
                p.twinkle = true;
                p.drag = 1.0;
            }
        }
        if (mist.get()) {
            int n = count(0.2);
            for (int i = 0; i < n; i++) {
                Neon.P p = mote(Neon.MIST, px + spread(r), py - 0.5 + rnd() * 1.0, pz + spread(r),
                        spread(0.005), 0.0, spread(0.005), life(120, 40), 0.7, 0xDDE6F0);
                p.drag = 1.0;
            }
        }
        if (dragon.get()) {
            int n = count(0.4);
            for (int i = 0; i < n; i++) {
                Neon.P p = mote(Neon.MIST, px + spread(r), py - 0.3 + rnd() * 1.0, pz + spread(r),
                        spread(0.01), 0.01, spread(0.01), life(90, 30), 0.4, 0xB45CFF);
                p.drag = 1.0;
            }
        }
        if (voidDust.get()) {
            int n = count(1.2);
            for (int i = 0; i < n; i++) {
                Neon.P p = mote(Neon.STREAK, px + spread(r), py + rnd() * 3.0, pz + spread(r),
                        spread(0.03), spread(0.03), spread(0.03), life(40, 20), 0.03, 0x8A4DFF);
                p.drag = 0.99;
            }
        }
    }
}
