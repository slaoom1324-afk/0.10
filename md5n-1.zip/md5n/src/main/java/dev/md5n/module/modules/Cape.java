package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.ModeSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Colors;
import dev.md5n.util.Fx;
import dev.md5n.util.Neon;

/**
 * عباءة من ألواح صلبة مظلّلة تتدلى من كتفك وتتمايل مع الحركة والهواء،
 * بدل نقاط جسيمات متناثرة. كل شي يُرسم عبر Neon.Painter.panel كل فريم.
 */
public class Cape extends Module {
    private record Look(double length, double widthTop, double taper, double swayAmp, double swayFreq,
                        int segs, boolean splitTail, boolean tattered, boolean trim,
                        boolean forceRainbow, boolean gradient, int bottomBlend, double bottomAmt) {}

    private static final String[] STYLES = {
            "Classic", "Royal", "Flowing", "Flames", "Starry",
            "Gradient", "Swallowtail", "Short Cloak", "Tattered", "Rainbow"
    };

    private static Look look(String s) {
        return switch (s) {
            case "Royal" -> new Look(1.00, 0.55, 0.90, 0.10, 0.9, 5, false, false, true, false, false, 0xFFD54F, 0.18);
            case "Flowing" -> new Look(1.15, 0.50, 0.80, 0.22, 1.4, 6, false, false, false, false, false, -1, 0.0);
            case "Flames" -> new Look(0.90, 0.50, 0.70, 0.18, 1.8, 5, false, false, false, false, false, 0xFF5A14, 0.80);
            case "Starry" -> new Look(0.95, 0.50, 0.85, 0.10, 0.8, 5, false, false, false, false, false, -1, 0.0);
            case "Gradient" -> new Look(0.95, 0.50, 0.85, 0.12, 1.0, 5, false, false, false, false, true, -1, 0.0);
            case "Swallowtail" -> new Look(0.95, 0.50, 0.85, 0.12, 1.0, 5, true, false, false, false, false, -1, 0.0);
            case "Short Cloak" -> new Look(0.55, 0.70, 0.95, 0.06, 0.7, 3, false, false, false, false, false, -1, 0.0);
            case "Tattered" -> new Look(0.90, 0.50, 0.80, 0.14, 1.1, 6, false, true, false, false, false, -1, 0.0);
            case "Rainbow" -> new Look(0.95, 0.50, 0.85, 0.12, 1.0, 5, false, false, false, true, false, -1, 0.0);
            default -> new Look(0.95, 0.50, 0.85, 0.12, 1.0, 5, false, false, false, false, false, -1, 0.0); // Classic
        };
    }

    private final ModeSetting style = mode("Style", "Classic", "10 solid-paneled cape looks", STYLES);
    private final ModeSetting color = mode("Color", "Theme", "Used only when Theme > Sync Cosmetics is off", Colors.MODES);
    private final NumSetting size = num("Size", 1.0, 0.5, 2.0, 0.1, "Overall cape size");
    private final NumSetting sway = num("Sway", 1.0, 0.2, 2.0, 0.1, "How much the cape billows with wind/movement");
    private final BoolSetting vfx = bool("VFX", false, "Add extra particle effects along the cape");
    private final ModeSetting vfxType = mode("VFX Type", "Sparkle", "Which effect is added when VFX is on",
            "Sparkle", "Glow", "Flame", "Soul", "Magic", "Electric", "Snow", "Petals");
    private final BoolSetting firstPerson = bool("First Person", false, "Also show it in first person (otherwise press F5 to see it)");

    public Cape() {
        super("Cape", Category.COSMETIC, "A solid, lit cape hanging from your shoulders that billows as you move");
    }

    @Override
    protected void onEnable() {
        Neon.addEffect(new CapeEffect());
    }

    @Override
    public void onTick() {
        if (!vfx.get() || mc.player == null) return;
        if (!firstPerson.get() && mc.options.getPerspective().isFirstPerson()) return;
        if (Neon.rnd() > 0.12) return;

        double yaw = Math.toRadians(mc.player.bodyYaw);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double h = mc.player.getHeight();
        Look lk = look(style.get());
        double drop = lk.length() * size.get() * 0.8;
        double px = mc.player.getX() - fx * 0.22;
        double py = mc.player.getY() + h * 0.82 - drop * (0.4 + Neon.rnd() * 0.6);
        double pz = mc.player.getZ() - fz * 0.22;
        Fx.vfx(vfxType.get(), px, py, pz, 0.0, 0.0, 0.0);
    }

    /** يرسم العباءة كل فريم، باستمرار، طول ما المود مشغّل. */
    private final class CapeEffect implements Neon.Effect {
        @Override
        public boolean tick() {
            return isEnabled();
        }

        @Override
        public void render(Neon.Painter p, double partial) {
            if (mc.player == null) return;
            if (!firstPerson.get() && mc.options.getPerspective().isFirstPerson()) return;

            Look lk = look(style.get());
            double t = System.currentTimeMillis() / 1000.0;
            double sz = size.get();
            int baseColor = Colors.resolve(color.get(), t, 0.0);

            double yaw = Math.toRadians(mc.player.bodyYaw);
            double[] right = {-Math.cos(yaw), 0.0, -Math.sin(yaw)};
            double[] back = {Math.sin(yaw), 0.0, -Math.cos(yaw)};
            double h = mc.player.getHeight();

            var vel = mc.player.getVelocity();
            double speed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
            double swayAmp = lk.swayAmp() * sway.get();
            int segs = lk.segs();
            double length = lk.length() * sz;

            double[] topCenter = {
                    mc.player.getX() + back[0] * 0.18,
                    mc.player.getY() + h * 0.82,
                    mc.player.getZ() + back[2] * 0.18
            };

            double[] prevL = null, prevR = null;
            double prevY = topCenter[1];

            for (int i = 0; i <= segs; i++) {
                double f = i / (double) segs;
                double w = (lk.widthTop() * sz) * (1.0 - f * (1.0 - lk.taper()));
                double segY = topCenter[1] - length * f;

                double billow = Math.sin(t * lk.swayFreq() + f * 2.2) * swayAmp * Math.pow(f, 1.3);
                billow += speed * 1.4 * f; // يتموج ويتخلف وراك وانت ماشي

                // العباءة تتخلف وراك مع البيلو (عكس اتجاه back)
                double cx = topCenter[0] - back[0] * billow;
                double cz = topCenter[2] - back[2] * billow;
                // ميل جانبي بسيط حول محور right مع التمايل
                double sideSway = Math.cos(t * lk.swayFreq() * 0.8 + f * 1.6) * swayAmp * 0.4 * f;

                double lx = cx + right[0] * (w * 0.5 + sideSway);
                double lz = cz + right[2] * (w * 0.5 + sideSway);
                double rxp = cx + right[0] * (-w * 0.5 + sideSway);
                double rzp = cz + right[2] * (-w * 0.5 + sideSway);

                double[] curL = {lx, segY, lz};
                double[] curR = {rxp, segY, rzp};

                if (prevL != null) {
                    boolean skip = lk.tattered() && Neon.rnd() < 0.12 * f;
                    if (!skip) {
                        double[] a = prevL, b = prevR, c = curR, d = curL;
                        double[] normal = Neon.normalOf(a, b, c);
                        double shade = Neon.shade(normal);

                        int rgb;
                        if (lk.forceRainbow()) {
                            rgb = Colors.hsv((t * 0.08 + f * 0.6) % 1.0, 0.65, 1.0);
                        } else if (lk.gradient()) {
                            rgb = Colors.lerp(baseColor, Colors.hueShift(baseColor, 55.0), f);
                        } else if (lk.bottomBlend() >= 0) {
                            rgb = Colors.lerp(baseColor, lk.bottomBlend(), Math.pow(f, 1.5) * lk.bottomAmt());
                        } else {
                            rgb = baseColor;
                        }
                        rgb = Colors.scale(rgb, shade);

                        double alpha = lk.tattered() ? (0.9 - f * 0.25) : 1.0;

                        if (lk.splitTail() && i == segs) {
                            double gap = w * 0.18;
                            double[] midL = Neon.lerp(prevL, curL, 1.0);
                            double[] midR = Neon.lerp(prevR, curR, 1.0);
                            double[] gapL = Neon.add(midL, Neon.mul(right, -gap));
                            double[] gapR = Neon.add(midR, Neon.mul(right, gap));
                            p.panel(prevL, Neon.lerp(prevL, prevR, 0.42), gapL, curL, rgb, alpha);
                            p.panel(Neon.lerp(prevL, prevR, 0.58), prevR, curR, gapR, rgb, alpha);
                        } else {
                            p.panel(a, b, c, d, rgb, alpha);
                        }
                    }
                } else if (lk.trim()) {
                    p.line(curL, curR, Colors.lerp(baseColor, 0xFFFFFF, 0.5), 0.9, 0.02);
                }

                prevL = curL;
                prevR = curR;
                prevY = segY;
            }

            if (lk.trim() && prevL != null && prevR != null) {
                p.line(prevL, prevR, lk.bottomBlend() >= 0 ? lk.bottomBlend() : baseColor, 0.9, 0.02);
            }
        }
    }
}
