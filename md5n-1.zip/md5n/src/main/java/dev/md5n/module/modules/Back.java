package dev.md5n.module.modules;

import dev.md5n.util.Colors;

public class Back extends Cosmetic {
    public Back() {
        super("Back", "Particle accessories on your back (press F5 to see)",
                new String[]{"Halo Disk", "Jetpack", "Orbs", "Gear", "Backpack", "Banner", "Crossed Swords", "Rings", "Blades", "Satellite"});
    }

    @Override
    protected void emit(String s) {
        double h = height;
        double sz = size.get();
        double cy = h * 0.7;

        switch (s) {
            case "Jetpack": {
                for (int side = -1; side <= 1; side += 2) {
                    line(side * 0.15, h * 0.75, -0.3, side * 0.15, h * 0.45, -0.3, 5, col(side > 0 ? 0.0 : 0.6));
                    int cnt = n(3);
                    for (int i = 0; i < cnt; i++) {
                        putV(side * 0.15 + spread(0.03), h * 0.43, -0.3 + spread(0.03),
                                Colors.lerp(col(0.0), 0xFF8A1F, rnd()), 0.0, -0.12, 0.0);
                    }
                }
                break;
            }
            case "Orbs": {
                for (int k = 0; k < 3; k++) {
                    double a = t * 2.5 + k * TAU / 3;
                    double ox = Math.cos(a) * 0.5 * sz;
                    double oy = cy + Math.sin(a) * 0.5 * sz;
                    put(ox, oy, -0.4, col(k / 3.0));
                    put(ox + 0.02, oy + 0.02, -0.4, col(k / 3.0));
                }
                break;
            }
            case "Gear": {
                for (int i = 0; i < 24; i++) {
                    double r = ((i % 3 == 0) ? 0.52 : 0.40) * sz;
                    double a = t * 0.8 + i * TAU / 24;
                    put(Math.cos(a) * r, cy + Math.sin(a) * r, -0.35, col(i / 24.0));
                }
                break;
            }
            case "Backpack": {
                double x0 = -0.2 * sz, x1 = 0.2 * sz;
                double y0 = h * 0.45, y1 = h * 0.8;
                double z0 = -0.2, z1 = -0.4;
                int c = col(0.0);
                for (double yy : new double[]{y0, y1}) {
                    line(x0, yy, z0, x1, yy, z0, 3, c);
                    line(x1, yy, z0, x1, yy, z1, 3, c);
                    line(x1, yy, z1, x0, yy, z1, 3, c);
                    line(x0, yy, z1, x0, yy, z0, 3, c);
                }
                for (double xx : new double[]{x0, x1}) {
                    for (double zz : new double[]{z0, z1}) {
                        line(xx, y0, zz, xx, y1, zz, 3, col(0.6));
                    }
                }
                break;
            }
            case "Banner": {
                double top = h * 0.85;
                double bottom = top - 0.8 * sz;
                double x0 = -0.2 * sz, x1 = 0.2 * sz;
                int c = col(0.0);
                line(x0, top, -0.3, x1, top, -0.3, 4, c);
                line(x0, top, -0.3, x0, bottom, -0.3, 6, c);
                line(x1, top, -0.3, x1, bottom, -0.3, 6, c);
                line(x0, bottom, -0.3, x1, bottom, -0.3, 4, c);
                line(0.0, top, -0.3, 0.0, bottom, -0.3, 6, col(0.6));
                break;
            }
            case "Crossed Swords": {
                line(-0.3 * sz, h * 0.4, -0.3, 0.3 * sz, h * 0.95, -0.3, 7, col(0.0));
                line(0.3 * sz, h * 0.4, -0.3, -0.3 * sz, h * 0.95, -0.3, 7, col(0.6));
                break;
            }
            case "Rings": {
                vring(0.0, cy, -0.35, 0.35 * sz, 14, t, col(0.0));
                vring(0.0, cy, -0.38, 0.55 * sz, 20, -t * 1.3, col(0.5));
                break;
            }
            case "Blades": {
                for (int k = 0; k < 4; k++) {
                    double a = t * 2.0 + k * Math.PI / 2.0;
                    line(Math.cos(a) * 0.15 * sz, cy + Math.sin(a) * 0.15 * sz, -0.35,
                            Math.cos(a) * 0.65 * sz, cy + Math.sin(a) * 0.65 * sz, -0.35, 5, col(k / 4.0));
                }
                break;
            }
            case "Satellite": {
                vring(0.0, cy, -0.4, 0.6 * sz, 10, 0.0, Colors.scale(col(0.0), 0.6));
                double a = t * 3.0;
                double ox = Math.cos(a) * 0.6 * sz;
                double oy = cy + Math.sin(a) * 0.6 * sz;
                put(ox, oy, -0.4, 0xFFFFFF);
                put(ox + 0.03, oy, -0.4, col(0.0));
                put(ox - 0.03, oy, -0.4, col(0.0));
                break;
            }
            default: {
                // Halo Disk
                vring(0.0, cy, -0.35, 0.5 * sz, 18, t * 0.5, col(0.0));
                break;
            }
        }
    }
}
