package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.ModeSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Colors;
import dev.md5n.util.Fx;
import dev.md5n.util.Neon;

/**
 * أجنحة بأسطح صلبة مظلّلة (مو جسيمات متفرقة): كل جناح مبني من ريشات/ألواح حقيقية
 * تُرسم كل فريم عبر Neon.Painter.panel(...)، فتبين سطح ثلاثي الأبعاد له إضاءة واتجاه.
 */
public class Wing extends Module {
    private record Look(double span, double droopDeg, double flapSpeed, int segments,
                        boolean taper, int tipBlend, double tipAmount, double alphaMul, double sweep) {}

    private static final String[] STYLES = {
            "Angel", "Demon", "Butterfly", "Dragon", "Fairy", "Phoenix", "Crystal", "Mech", "Ghost", "Void"
    };

    private static Look look(String s) {
        return switch (s) {
            case "Demon" -> new Look(0.85, 32, 0.8, 4, true, 0x1A0A0A, 0.5, 1.0, 0.45);
            case "Butterfly" -> new Look(0.62, -8, 3.2, 2, false, 0xFFFFFF, 0.25, 0.9, 0.15);
            case "Dragon" -> new Look(1.30, 22, 0.7, 4, false, 0x10050A, 0.35, 1.0, 0.55);
            case "Fairy" -> new Look(0.48, -6, 4.0, 2, true, 0xFFFFFF, 0.35, 0.65, 0.10);
            case "Phoenix" -> new Look(1.00, 16, 1.0, 5, true, 0xFF6A1A, 0.6, 1.0, 0.35);
            case "Crystal" -> new Look(0.90, 6, 0.3, 4, false, 0xFFFFFF, 0.45, 1.0, 0.30);
            case "Mech" -> new Look(1.00, 2, 0.15, 3, false, 0x202020, 0.4, 1.0, 0.20);
            case "Ghost" -> new Look(1.10, 26, 1.4, 4, true, 0xFFFFFF, 0.45, 0.6, 0.40);
            case "Void" -> new Look(1.00, 30, 1.0, 4, true, 0x120022, 0.65, 1.0, 0.45);
            default -> new Look(1.00, 14, 1.0, 5, true, 0xFFFFFF, 0.3, 1.0, 0.30); // Angel
        };
    }

    private final ModeSetting style = mode("Style", "Angel", "10 solid-paneled wing looks", STYLES);
    private final ModeSetting color = mode("Color", "Theme", "Used only when Theme > Sync Cosmetics is off", Colors.MODES);
    private final NumSetting size = num("Size", 1.0, 0.5, 2.0, 0.1, "Overall wing size");
    private final NumSetting flapAmount = num("Flap Amount", 1.0, 0.2, 2.0, 0.1, "How far the wings flap up/down");
    private final BoolSetting vfx = bool("VFX", false, "Add extra particle effects at the wingtips");
    private final ModeSetting vfxType = mode("VFX Type", "Sparkle", "Which effect is added when VFX is on",
            "Sparkle", "Glow", "Flame", "Soul", "Magic", "Electric", "Snow", "Petals");
    private final BoolSetting firstPerson = bool("First Person", false, "Also show it in first person (otherwise press F5 to see it)");

    public Wing() {
        super("Wing", Category.COSMETIC, "Solid, lit wing panels on your back that flap");
    }

    @Override
    protected void onEnable() {
        Neon.addEffect(new WingEffect());
    }

    @Override
    public void onTick() {
        if (!vfx.get() || mc.player == null) return;
        if (!firstPerson.get() && mc.options.getPerspective().isFirstPerson()) return;
        if (Neon.rnd() > 0.12) return;

        Look lk = look(style.get());
        double yaw = Math.toRadians(mc.player.bodyYaw);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        double h = mc.player.getHeight();
        int side = Neon.rnd() < 0.5 ? -1 : 1;
        double span = lk.span() * size.get();
        double sweepBack = lk.sweep() * span;
        double tipX = mc.player.getX() + rx * side * span * 0.6 + fx * (-sweepBack);
        double tipY = mc.player.getY() + h * 0.75 + span * 0.5;
        double tipZ = mc.player.getZ() + rz * side * span * 0.6 + fz * (-sweepBack);
        Fx.vfx(vfxType.get(), tipX, tipY, tipZ, 0.0, 0.01, 0.0);
    }

    /** يرسم الجناحين كل فريم، باستمرار، طول ما المود مشغّل. */
    private final class WingEffect implements Neon.Effect {
        @Override
        public boolean tick() {
            return isEnabled();
        }

        @Override
        public void render(Neon.Painter p, double partial) {
            if (mc.player == null) return;
            if (!firstPerson.get() && mc.options.getPerspective().isFirstPerson()) return;

            Look lk = look(style.get());
            double t = System.currentTimeMillis() / 1000.0;
            double sz = size.get();
            int baseColor = Colors.resolve(color.get(), t, 0.0);

            double yaw = Math.toRadians(mc.player.bodyYaw);
            double[] right = {-Math.cos(yaw), 0.0, -Math.sin(yaw)};
            double[] back = {-(-Math.sin(yaw)), 0.0, -Math.cos(yaw)};
            double[] up = {0.0, 1.0, 0.0};

            double h = mc.player.getHeight();
            double flap = Math.toRadians(lk.droopDeg()) + Math.sin(t * lk.flapSpeed() * 2.0) * (0.45 * flapAmount.get());
            double span = lk.span() * sz;
            double sweep = lk.sweep();
            int segs = lk.segments();

            for (int side = -1; side <= 1; side += 2) {
                double[] base = {
                        mc.player.getX() + right[0] * side * 0.12,
                        mc.player.getY() + h * 0.74,
                        mc.player.getZ() + right[2] * side * 0.12
                };
                double[] spanDir = {
                        right[0] * side * Math.cos(flap) + up[0] * Math.sin(flap),
                        up[1] * Math.sin(flap),
                        right[2] * side * Math.cos(flap) + up[2] * Math.sin(flap)
                };

                for (int i = 0; i < segs; i++) {
                    double f0 = i / (double) segs;
                    double f1 = (i + 1) / (double) segs;
                    double len0 = span * f0;
                    double len1 = span * f1;

                    double[] c0 = Neon.add(base, Neon.add(Neon.mul(spanDir, len0), Neon.mul(back, -sweep * span * f0)));
                    double[] c1 = Neon.add(base, Neon.add(Neon.mul(spanDir, len1), Neon.mul(back, -sweep * span * f1)));

                    double w0 = (0.11 * sz) * (lk.taper() ? (1.0 - f0 * 0.6) : 1.0);
                    double w1 = (0.11 * sz) * (lk.taper() ? (1.0 - f1 * 0.65) : 1.0);

                    double[] a = Neon.add(c0, Neon.mul(back, w0 * 0.5));
                    double[] b = Neon.add(c0, Neon.mul(back, -w0 * 0.5));
                    double[] c = Neon.add(c1, Neon.mul(back, -w1 * 0.5));
                    double[] d = Neon.add(c1, Neon.mul(back, w1 * 0.5));

                    double[] normal = Neon.normalOf(a, b, c);
                    double shade = Neon.shade(normal);
                    int blended = lk.tipBlend() >= 0
                            ? Colors.lerp(baseColor, lk.tipBlend(), f1 * lk.tipAmount())
                            : baseColor;
                    int rgb = Colors.scale(blended, shade);

                    p.panel(a, b, c, d, rgb, lk.alphaMul());
                }
            }
        }
    }
}
