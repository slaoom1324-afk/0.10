package dev.md5n.mixin;

import dev.md5n.Md5n;
import dev.md5n.module.modules.Sky;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * اللعبة تسأل ClientWorld عن لون السماء والغيوم كل فريم.
 * نكتب المعالجات بدون وسائط وبنوع Object، فتشتغل سواء كانت الدالة ترجع Vec3d أو int حسب الإصدار.
 */
@Mixin(ClientWorld.class)
public class ClientWorldMixin {

    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true, require = 0)
    private void md5n$skyColor(CallbackInfoReturnable<Object> cir) {
        if (Md5n.modules == null) return;
        Sky sky = Md5n.modules.get(Sky.class);
        if (sky == null || !sky.isEnabled()) return;

        Object original = cir.getReturnValue();
        if (original instanceof Vec3d vec) {
            sky.hookHits++;
            cir.setReturnValue(sky.apply(vec));
        } else if (original instanceof Integer argb) {
            sky.hookHits++;
            cir.setReturnValue(sky.applyArgb(argb));
        }
    }

    @Inject(method = "getCloudsColor", at = @At("RETURN"), cancellable = true, require = 0)
    private void md5n$cloudColor(CallbackInfoReturnable<Object> cir) {
        if (Md5n.modules == null) return;
        Sky sky = Md5n.modules.get(Sky.class);
        if (sky == null || !sky.isEnabled() || !sky.tintsClouds()) return;

        Object original = cir.getReturnValue();
        if (original instanceof Vec3d vec) {
            cir.setReturnValue(sky.applyCloud(vec));
        } else if (original instanceof Integer argb) {
            cir.setReturnValue(sky.applyCloudArgb(argb));
        }
    }
}
