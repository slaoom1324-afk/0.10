package dev.md5n.util;

import dev.md5n.Md5n;
import dev.md5n.module.modules.ThemeSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * محرك مؤثرات نيون مخصص: جسيماتنا ومجسماتنا (سلاسل، حلقات، نجوم...) تُحسب وتُرسم بالكامل من الكود،
 * بدون أي جسيمة من ماينكرافت. تُسقط نقاط العالم على الشاشة وترسمها بتوهج.
 */
public final class Neon {
    private Neon() {}

    public static final double TAU = Math.PI * 2.0;

    // أنواع الجسيمات
    public static final int ORB = 0, SPARK = 1, FLAKE = 2, PETAL = 3, SPECK = 4,
            RING = 5, WISP = 6, RUNE = 7, MIST = 8, STREAK = 9;

    public static final class P {
        public double x, y, z, vx, vy, vz;
        public double gravity = 0.0;
        public double drag = 0.97;
        public double sway = 0.0;
        public double phase;
        public double size;
        public int age, life, kind, rgb;
        public boolean twinkle;
    }

    /** مؤثر مركّب (سلسلة، مدار، عاصفة...) يرسم نفسه كل فريم. */
    public interface Effect {
        boolean tick();                                // false = انتهى
        void render(Painter p, double partial);
    }

    private static final List<P> PARTS = new ArrayList<>();
    private static final List<Effect> EFFECTS = new ArrayList<>();
    private static long lastTickNs = System.nanoTime();

    // ------------------------------------------------------------ رياضيات
    public static double rnd() { return ThreadLocalRandom.current().nextDouble(); }

    public static double hash(double v) {
        double s = Math.sin(v * 12.9898 + 78.233) * 43758.5453;
        return s - Math.floor(s);
    }

    public static double[] v(double x, double y, double z) { return new double[]{x, y, z}; }

    public static double[] add(double[] a, double[] b) { return new double[]{a[0] + b[0], a[1] + b[1], a[2] + b[2]}; }

    public static double[] mul(double[] a, double s) { return new double[]{a[0] * s, a[1] * s, a[2] * s}; }

    public static double[] lerp(double[] a, double[] b, double t) {
        return new double[]{a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t};
    }

    /** اتجاه إضاءة ثابت (من فوق-قدام)، تستخدمه الأسطح الصلبة عشان تبين بإحساس ثلاثي الأبعاد. */
    public static final double[] LIGHT_DIR = normStatic(new double[]{0.35, 0.8, 0.5});

    private static double[] normStatic(double[] a) {
        double l = Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
        return new double[]{a[0] / l, a[1] / l, a[2] / l};
    }

    /** سطوع السطح حسب اتجاهه بالنسبة لاتجاه الإضاءة (0.45 أرضية + إضاءة مباشرة). */
    public static double shade(double[] normal) {
        double d = normal[0] * LIGHT_DIR[0] + normal[1] * LIGHT_DIR[1] + normal[2] * LIGHT_DIR[2];
        return 0.45 + 0.55 * Math.max(0.0, d);
    }

    /** الاتجاه العمودي على مثلث a-b-c (مو بالضرورة وحدة). */
    public static double[] normalOf(double[] a, double[] b, double[] c) {
        double[] e1 = {b[0] - a[0], b[1] - a[1], b[2] - a[2]};
        double[] e2 = {c[0] - a[0], c[1] - a[1], c[2] - a[2]};
        return norm(cross(e1, e2));
    }

    public static double[] cross(double[] a, double[] b) {
        return new double[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    public static double[] norm(double[] a) {
        double l = Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
        if (l < 1e-9) return new double[]{0.0, 1.0, 0.0};
        return new double[]{a[0] / l, a[1] / l, a[2] / l};
    }

    /** يدوّر (x,y,z) حول المحور الرأسي. */
    public static double[] rotY(double x, double y, double z, double ang) {
        double c = Math.cos(ang), s = Math.sin(ang);
        return new double[]{x * c + z * s, y, -x * s + z * c};
    }

    /** متجه وحدة شبه عشوائي ثابت من بذرة. */
    public static double[] unit(double seed) {
        double u = hash(seed) * 2.0 - 1.0;
        double th = hash(seed + 17.3) * TAU;
        double s = Math.sqrt(Math.max(0.0, 1.0 - u * u));
        return new double[]{s * Math.cos(th), u, s * Math.sin(th)};
    }

    // ------------------------------------------------------------ إدارة
    public static P spawn(int kind, double x, double y, double z, double vx, double vy, double vz,
                          int life, double size, int rgb) {
        P p = new P();
        p.kind = kind;
        p.x = x;
        p.y = y;
        p.z = z;
        p.vx = vx;
        p.vy = vy;
        p.vz = vz;
        p.life = Math.max(2, life);
        p.size = size;
        p.rgb = rgb & 0xFFFFFF;
        p.phase = rnd() * TAU;
        if (PARTS.size() >= 2500) PARTS.subList(0, 300).clear();
        PARTS.add(p);
        return p;
    }

    public static void addEffect(Effect e) {
        if (EFFECTS.size() >= 40) EFFECTS.remove(0);
        EFFECTS.add(e);
    }

    public static void clear() {
        PARTS.clear();
        EFFECTS.clear();
    }

    /** يُستدعى كل تيك. */
    public static void tick() {
        lastTickNs = System.nanoTime();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) {
            clear();
            return;
        }

        for (int i = PARTS.size() - 1; i >= 0; i--) {
            P p = PARTS.get(i);
            p.age++;
            if (p.age >= p.life) {
                int last = PARTS.size() - 1;
                PARTS.set(i, PARTS.get(last));
                PARTS.remove(last);
                continue;
            }
            double sx = 0.0, sz = 0.0;
            if (p.sway != 0.0) {
                sx = Math.sin(p.age * 0.18 + p.phase) * p.sway;
                sz = Math.cos(p.age * 0.15 + p.phase) * p.sway;
            }
            p.x += p.vx + sx;
            p.y += p.vy;
            p.z += p.vz + sz;
            p.vx *= p.drag;
            p.vz *= p.drag;
            p.vy = p.vy * p.drag - p.gravity;
        }

        for (int i = EFFECTS.size() - 1; i >= 0; i--) {
            if (!EFFECTS.get(i).tick()) EFFECTS.remove(i);
        }
    }

    /** يُستدعى كل فريم من الـ HUD. */
    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || mc.gameRenderer == null) return;
        if (PARTS.isEmpty() && EFFECTS.isEmpty()) return;

        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null) return;

        ThemeSettings theme = Md5n.modules == null ? null : Md5n.modules.get(ThemeSettings.class);
        double fov = mc.options.getFov().getValue() + (theme == null ? 0.0 : theme.fxFov());
        double glow = theme == null ? 1.0 : theme.fxGlow();
        double partial = Math.max(0.0, Math.min(1.0, (System.nanoTime() - lastTickNs) / 50_000_000.0));

        Painter painter = new Painter(ctx, cam, fov, glow);
        for (int i = 0; i < EFFECTS.size(); i++) EFFECTS.get(i).render(painter, partial);
        for (int i = 0; i < PARTS.size(); i++) painter.part(PARTS.get(i), partial);
    }

    // ------------------------------------------------------------ الرسّام
    public static final class Painter {
        private final DrawContext ctx;
        private final double cx, cy, cz, fx, fy, fz, rx, rz, ux, uy, uz, scale, glow;
        private final int w, h;
        private final double[] tmp = new double[3];

        Painter(DrawContext ctx, Camera cam, double fovDeg, double glow) {
            this.ctx = ctx;
            Vec3d pos = cam.getPos();
            this.cx = pos.x;
            this.cy = pos.y;
            this.cz = pos.z;
            double yaw = Math.toRadians(cam.getYaw());
            double pitch = Math.toRadians(cam.getPitch());
            double cosY = Math.cos(yaw), sinY = Math.sin(yaw), cosP = Math.cos(pitch), sinP = Math.sin(pitch);
            this.fx = -sinY * cosP;
            this.fy = -sinP;
            this.fz = cosY * cosP;
            this.rx = -cosY;
            this.rz = -sinY;
            this.ux = -sinY * sinP;
            this.uy = cosP;
            this.uz = cosY * sinP;
            this.w = ctx.getScaledWindowWidth();
            this.h = ctx.getScaledWindowHeight();
            double f = Math.max(30.0, Math.min(140.0, fovDeg));
            this.scale = (this.h / 2.0) / Math.tan(Math.toRadians(f) / 2.0);
            this.glow = glow;
        }

        private static double clamp(double v, double lo, double hi) {
            return Math.max(lo, Math.min(hi, v));
        }

        private static double farFade(double depth) {
            return depth <= 40.0 ? 1.0 : Math.max(0.0, 1.0 - (depth - 40.0) / 50.0);
        }

        /** يسقط نقطة من العالم على الشاشة: النتيجة في tmp = {x, y, عمق}. */
        public boolean project(double x, double y, double z) {
            double dx = x - cx, dy = y - cy, dz = z - cz;
            double zc = dx * fx + dy * fy + dz * fz;
            if (zc < 0.15) return false;
            double xc = dx * rx + dz * rz;
            double yc = dx * ux + dy * uy + dz * uz;
            tmp[0] = w / 2.0 + xc / zc * scale;
            tmp[1] = h / 2.0 - yc / zc * scale;
            tmp[2] = zc;
            return true;
        }

        // ---------------- رسم 2D أساسي
        private void disc(double x, double y, double r, int rgb, double a) {
            int al = (int) Math.max(0.0, Math.min(255.0, a * 255.0));
            if (al < 5) return;
            int color = (al << 24) | (rgb & 0xFFFFFF);
            int ix = (int) Math.round(x), iy = (int) Math.round(y);
            int ri = Math.max(1, (int) Math.round(r));
            if (ri <= 2) ctx.fill(ix - ri, iy - ri, ix + ri, iy + ri, color);
            else Draw.roundRect(ctx, ix - ri, iy - ri, ix + ri, iy + ri, ri, color);
        }

        private void dot1(double x, double y, int rgb, double a) {
            int al = (int) Math.max(0.0, Math.min(255.0, a * 255.0));
            if (al < 5) return;
            int ix = (int) Math.round(x), iy = (int) Math.round(y);
            ctx.fill(ix, iy, ix + 1, iy + 1, (al << 24) | (rgb & 0xFFFFFF));
        }

        private void glowAt(double x, double y, double r, int rgb, double a) {
            a *= glow;
            int core = Colors.lerp(rgb, 0xFFFFFF, 0.7);
            disc(x, y, r * 2.3, rgb, a * 0.10);
            disc(x, y, r * 1.5, rgb, a * 0.22);
            disc(x, y, r * 0.95, rgb, a * 0.55);
            disc(x, y, Math.max(0.8, r * 0.5), core, a * 0.95);
        }

        private void stroke(double x, double y, double r, int rgb, double a) {
            a *= glow;
            disc(x, y, r * 1.9, rgb, a * 0.20);
            disc(x, y, Math.max(0.7, r * 0.8), Colors.lerp(rgb, 0xFFFFFF, 0.6), a * 0.9);
        }

        private void line2(double x1, double y1, double x2, double y2, int rgb, double a) {
            double dx = x2 - x1, dy = y2 - y1;
            int steps = (int) Math.max(1, Math.min(40, Math.ceil(Math.sqrt(dx * dx + dy * dy))));
            for (int i = 0; i <= steps; i++) {
                double f = i / (double) steps;
                dot1(x1 + dx * f, y1 + dy * f, rgb, a);
            }
        }

        // ---------------- رسم 3D للمؤثرات
        public void orb(double x, double y, double z, double worldR, int rgb, double alpha) {
            if (!project(x, y, z)) return;
            double r = clamp(worldR * scale / tmp[2], 1.0, 16.0);
            glowAt(tmp[0], tmp[1], r, rgb, alpha * farFade(tmp[2]));
        }

        public void orb(double[] p, double worldR, int rgb, double alpha) {
            orb(p[0], p[1], p[2], worldR, rgb, alpha);
        }

        /** قرص ناعم كبير (غيوم/ضباب). */
        public void cloud(double x, double y, double z, double worldR, int rgb, double alpha) {
            if (!project(x, y, z)) return;
            double r = clamp(worldR * scale / tmp[2], 2.0, 90.0);
            double a = alpha * glow * farFade(tmp[2]);
            disc(tmp[0], tmp[1], r, rgb, a * 0.16);
            disc(tmp[0], tmp[1], r * 0.62, rgb, a * 0.14);
        }

        public void line(double x1, double y1, double z1, double x2, double y2, double z2,
                         int rgb, double alpha, double worldW) {
            if (!project(x1, y1, z1)) return;
            double ax = tmp[0], ay = tmp[1], az = tmp[2];
            if (!project(x2, y2, z2)) return;
            double bx = tmp[0], by = tmp[1], bz = tmp[2];
            double dx = bx - ax, dy = by - ay;
            double len = Math.sqrt(dx * dx + dy * dy);
            if (len > 900.0) return;
            double depth = (az + bz) * 0.5;
            double r = clamp(worldW * scale / depth, 0.7, 5.0);
            double a = alpha * farFade(depth);
            int steps = (int) Math.max(1, Math.min(70, Math.ceil(len / Math.max(1.0, r * 1.2))));
            for (int i = 0; i <= steps; i++) {
                double f = i / (double) steps;
                stroke(ax + dx * f, ay + dy * f, r, rgb, a);
            }
        }

        public void line(double[] a, double[] b, int rgb, double alpha, double worldW) {
            line(a[0], a[1], a[2], b[0], b[1], b[2], rgb, alpha, worldW);
        }

        /**
         * مربع صلب (4 أركان بالعالم، بالترتيب حول الشكل) يُملأ لونًا كامل بدل نقاط متفرقة،
         * وله حافة لامعة خفيفة. هذا اللي يخلي الكوزمتك يبين سطح صلب بدل سحابة جسيمات.
         */
        public void panel(double[] a, double[] b, double[] c, double[] d, int rgb, double alpha) {
            if (!project(a[0], a[1], a[2])) return;
            double ax = tmp[0], ay = tmp[1], az = tmp[2];
            if (!project(b[0], b[1], b[2])) return;
            double bx = tmp[0], by = tmp[1], bz = tmp[2];
            if (!project(c[0], c[1], c[2])) return;
            double cx = tmp[0], cy = tmp[1], cz = tmp[2];
            if (!project(d[0], d[1], d[2])) return;
            double dx = tmp[0], dy = tmp[1], dz = tmp[2];

            double depth = (az + bz + cz + dz) / 4.0;
            double a2 = alpha * farFade(depth);
            if (a2 <= 0.01) return;

            fillPoly(new double[]{ax, bx, cx, dx}, new double[]{ay, by, cy, dy}, rgb, a2 * glow);

            // حافة لامعة خفيفة تبرز شكل اللوح
            int edge = Colors.lerp(rgb, 0xFFFFFF, 0.35);
            double ew = 0.015;
            line(a, b, edge, alpha * 0.6, ew);
            line(b, c, edge, alpha * 0.6, ew);
            line(c, d, edge, alpha * 0.6, ew);
            line(d, a, edge, alpha * 0.6, ew);
        }

        /** تعبئة مربّع في فراغ الشاشة (سطر-سطر) بعد ما تحسقط أركانه. */
        private void fillPoly(double[] xs, double[] ys, int rgb, double alpha) {
            int al = (int) Math.max(0.0, Math.min(255.0, alpha * 255.0));
            if (al < 4) return;
            int color = (al << 24) | (rgb & 0xFFFFFF);
            int n = xs.length;

            double minY = Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                minY = Math.min(minY, ys[i]);
                maxY = Math.max(maxY, ys[i]);
            }
            int y0 = Math.max(0, (int) Math.floor(minY));
            int y1 = Math.min(h, (int) Math.ceil(maxY));
            if (y1 <= y0 || y1 - y0 > 500) return;

            for (int y = y0; y < y1; y++) {
                double yc = y + 0.5;
                double xa = 0.0, xb = 0.0;
                int found = 0;
                for (int i = 0; i < n; i++) {
                    int j = (i + 1) % n;
                    double y1e = ys[i], y2e = ys[j];
                    boolean crosses = (y1e <= yc && y2e > yc) || (y2e <= yc && y1e > yc);
                    if (!crosses) continue;
                    double t = (yc - y1e) / (y2e - y1e);
                    double x = xs[i] + (xs[j] - xs[i]) * t;
                    if (found == 0) {
                        xa = x;
                        found = 1;
                    } else {
                        xb = x;
                        found = 2;
                    }
                }
                if (found < 2) continue;
                int xl = (int) Math.round(Math.min(xa, xb));
                int xr = (int) Math.round(Math.max(xa, xb));
                xl = Math.max(0, xl);
                xr = Math.min(w, xr);
                if (xr > xl) ctx.fill(xl, y, xr, y + 1, color);
            }
        }

        /** حلقة/بيضاوي في الفراغ: مركز c ومحوران u وv. dimBack يعتّم النصف الخلفي. */
        public void loop(double[] c, double[] u, double[] v, double a, double b, int segs,
                         int rgb, double alpha, double worldW, boolean dimBack) {
            double ref = -1.0;
            if (dimBack && project(c[0], c[1], c[2])) ref = tmp[2];
            double[] prev = null;
            double prevDepth = 0.0;
            for (int i = 0; i <= segs; i++) {
                double th = i * TAU / segs;
                double ca = Math.cos(th) * a, sb = Math.sin(th) * b;
                double[] pt = {c[0] + u[0] * ca + v[0] * sb, c[1] + u[1] * ca + v[1] * sb, c[2] + u[2] * ca + v[2] * sb};
                double d = -1.0;
                if (ref > 0 && project(pt[0], pt[1], pt[2])) d = tmp[2];
                if (prev != null) {
                    double al = alpha;
                    if (ref > 0 && d > ref && prevDepth > ref) al *= 0.5;
                    line(prev, pt, rgb, al, worldW);
                }
                prev = pt;
                prevDepth = d;
            }
        }

        // ---------------- جسيمات
        void part(P q, double partial) {
            double age = q.age + partial;
            double f = age / q.life;
            if (f >= 1.0) return;
            double env = Math.min(1.0, f / 0.15) * Math.min(1.0, (1.0 - f) / 0.35);
            if (q.twinkle) env *= 0.55 + 0.45 * Math.sin(age * 0.5 + q.phase);
            if (env < 0.03) return;

            double x = q.x + q.vx * partial, y = q.y + q.vy * partial, z = q.z + q.vz * partial;
            if (!project(x, y, z)) return;
            double sx = tmp[0], sy = tmp[1], zc = tmp[2];
            if (sx < -60 || sx > w + 60 || sy < -60 || sy > h + 60) return;

            double a = env * farFade(zc);
            double r = clamp(q.size * scale / zc, 0.9, q.kind == MIST ? 70.0 : 14.0);
            int ix = (int) Math.round(sx), iy = (int) Math.round(sy);
            int al = (int) Math.max(0.0, Math.min(255.0, a * glow * 255.0));
            int color = (al << 24) | (q.rgb & 0xFFFFFF);

            switch (q.kind) {
                case SPARK: {
                    glowAt(sx, sy, r * 0.8, q.rgb, a);
                    int len = (int) Math.round(r * 3.2);
                    int arm = (int) Math.round(al * 0.8) << 24 | (q.rgb & 0xFFFFFF);
                    ctx.fill(ix - len, iy, ix + len + 1, iy + 1, arm);
                    ctx.fill(ix, iy - len, ix + 1, iy + len + 1, arm);
                    break;
                }
                case FLAKE: {
                    int len = (int) Math.max(2, Math.round(r * 2.6));
                    int d = (int) Math.max(1, Math.round(len * 0.7));
                    ctx.fill(ix - len, iy, ix + len + 1, iy + 1, color);
                    ctx.fill(ix, iy - len, ix + 1, iy + len + 1, color);
                    ctx.fill(ix - d, iy - d, ix - d + 1, iy - d + 1, color);
                    ctx.fill(ix + d, iy - d, ix + d + 1, iy - d + 1, color);
                    ctx.fill(ix - d, iy + d, ix - d + 1, iy + d + 1, color);
                    ctx.fill(ix + d, iy + d, ix + d + 1, iy + d + 1, color);
                    break;
                }
                case PETAL: {
                    double ang = q.phase + age * 0.06;
                    for (int i = -1; i <= 1; i++) {
                        disc(sx + Math.cos(ang) * i * r * 0.7, sy + Math.sin(ang) * i * r * 0.7, r * 0.65, q.rgb, a * glow * 0.9);
                    }
                    break;
                }
                case SPECK: {
                    int s = (int) Math.max(1, Math.round(r * 0.8));
                    ctx.fill(ix, iy, ix + s + 1, iy + s + 1, color);
                    break;
                }
                case RING: {
                    for (int i = 0; i < 12; i++) {
                        double ang = i * TAU / 12.0;
                        dot1(sx + Math.cos(ang) * r * 1.6, sy + Math.sin(ang) * r * 1.6, q.rgb, a * glow);
                    }
                    disc(sx, sy, Math.max(0.8, r * 0.4), q.rgb, a * glow * 0.4);
                    break;
                }
                case WISP: {
                    for (int k = 0; k < 6; k++) {
                        double sway = Math.sin(age * 0.2 + q.phase + k * 0.5) * r * 0.3;
                        disc(sx + sway, sy + k * r * 0.8, r * (1.0 - k * 0.13), q.rgb, a * glow * (1.0 - k * 0.16) * 0.8);
                    }
                    break;
                }
                case RUNE: {
                    double d = Math.max(3.0, r * 2.2);
                    double[][] pts = {{sx, sy - d}, {sx + d, sy}, {sx, sy + d}, {sx - d, sy}, {sx, sy - d}};
                    for (int i = 0; i < 4; i++) line2(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], q.rgb, a * glow);
                    disc(sx, sy, Math.max(0.8, r * 0.5), Colors.lerp(q.rgb, 0xFFFFFF, 0.6), a * glow);
                    break;
                }
                case MIST: {
                    disc(sx, sy, r, q.rgb, a * glow * 0.16);
                    disc(sx, sy, r * 0.65, q.rgb, a * glow * 0.12);
                    break;
                }
                case STREAK: {
                    line(x, y, z, x - q.vx * 4.0, y - q.vy * 4.0, z - q.vz * 4.0, q.rgb, a, q.size);
                    break;
                }
                default: {
                    glowAt(sx, sy, r, q.rgb, a);
                    break;
                }
            }
        }
    }
}
