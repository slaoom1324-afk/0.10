package dev.md5n.util;

/** كل المؤثرات تمر من هنا إلى محرك Neon (بدون جسيمات ماينكرافت). */
public final class Fx {
    private Fx() {}

    private static int life(int base, int var) {
        return base + (int) (Neon.rnd() * var);
    }

    /** نقطة نيون صغيرة بلون RGB (تستخدمها الكوزمتك). */
    public static void dust(int rgb, float scale, double x, double y, double z, double vx, double vy, double vz) {
        Neon.P p = Neon.spawn(Neon.ORB, x, y, z, vx, vy, vz, life(11, 9), 0.07 * scale, rgb);
        p.drag = 0.94;
    }

    /** دخان/ضباب ناعم. */
    public static void puff(double x, double y, double z, double vx, double vy, double vz) {
        Neon.P p = Neon.spawn(Neon.MIST, x, y, z, vx, vy, vz, life(16, 8), 0.16, 0xE8EEF5);
        p.drag = 0.95;
    }

    /** تأثير VFX فوق الكوزمتك (أشكال نيون مخصصة). */
    public static void vfx(String type, double x, double y, double z, double vx, double vy, double vz) {
        Neon.P p;
        switch (type) {
            case "Glow":
                p = Neon.spawn(Neon.ORB, x, y, z, vx, vy, vz, life(24, 16), 0.05, 0xE8FF7A);
                p.twinkle = true;
                break;
            case "Flame":
                p = Neon.spawn(Neon.ORB, x, y, z, vx, 0.05 + Neon.rnd() * 0.03, vz, life(14, 8), 0.045, 0xFF8A2B);
                p.twinkle = true;
                break;
            case "Soul":
                Neon.spawn(Neon.WISP, x, y, z, vx, 0.03, vz, life(24, 12), 0.06, 0x7FE8FF);
                break;
            case "Magic":
                p = Neon.spawn(Neon.RUNE, x, y, z, vx, 0.02, vz, life(24, 12), 0.06, 0xC79BFF);
                p.twinkle = true;
                break;
            case "Electric":
                p = Neon.spawn(Neon.SPARK, x, y, z, vx, vy, vz, life(8, 6), 0.045, 0x8FD8FF);
                p.twinkle = true;
                break;
            case "Snow":
                p = Neon.spawn(Neon.FLAKE, x, y, z, vx, -0.04, vz, life(24, 12), 0.04, 0xF4FAFF);
                p.drag = 1.0;
                break;
            case "Petals":
                p = Neon.spawn(Neon.PETAL, x, y, z, vx, -0.02, vz, life(28, 12), 0.055, 0xFFB7D5);
                p.drag = 1.0;
                p.sway = 0.004;
                break;
            case "Portal":
                p = Neon.spawn(Neon.ORB, x, y, z, vx, vy, vz, life(20, 10), 0.04, 0x8A4DFF);
                p.twinkle = true;
                break;
            default:
                p = Neon.spawn(Neon.SPARK, x, y, z, vx, 0.01, vz, life(18, 10), 0.04, 0xFFFFFF);
                p.twinkle = true;
                break;
        }
    }
}
